<?php include("header.php"); ?>
<div class="page-body-wrapper">
    <?php include("mainsidebar.php"); ?>
    <div class="page-body">
        <div class="container-fluid">
            <div class="page-title">
                <div class="row">
                    <div class="col-sm-6 p-0">
                        <h3>Asign Vehicle</h3>
                    </div>
                </div>
            </div>
            <div class="container-fluid default-dashboard">
                <div class="form-container">
                <form method="post" action="<?php echo base_url(); ?>/Admin/update_tyer_data">
                    <input type="hidden" id="vehicle_id" class="form-control" name="vehicle_id" value="<?=$lvehicle_id?>" />
                    <div>
                        <label>Location</label>
                        <select id="locationSelect" name="location" class="form-control">
                            <option value="">Select location</option>
                            <?php foreach ($location as $loc) { ?>
                                <option value="<?= $loc->location_id; ?>"><?= $loc->location_name; ?></option>
                            <?php } ?>
                        </select>
                    </div>

                    <div>
                        <label>Select Tyer</label>
                        <select class="form-control select2-hidden-accessible tyerSelect" name="tyer_id" id="single1" data-select2-id="single1" tabindex="-1" aria-hidden="true">
                            <option value="">Select Tyer</option>
                        </select>
                    </div>
                    
                    <div id="locationDetails">
                        <label>Tyer Position</label>
                        <select class="form-control" name="tyer_position">
                            <option value="Front Right">Front Right</option>
                            <option value="Front Left">Front Left</option>
                            <option value="Rear1 Right">Rear1 Right</option>
                            <option value="Rear1 Left">Rear1 Left</option>
                            <option value="Rear2 Right">Rear2 Right</option>
                            <option value="Rear2 Left">Rear2 Left</option>
                            <option value="Rear3 Right">Rear3 Right</option>
                            <option value="Rear3 Left">Rear3 Left</option>
                            <option value="Rear4 Right">Rear4 Right</option>
                            <option value="Rear4 Left">Rear4 Left</option>
                            <option value="Rear5 Right">Rear5 Right</option>
                            <option value="Rear5 Left">Rear5 Left</option>
                            <option value="Rear6 Right">Rear6 Right</option>
                            <option value="Rear6 Left">Rear6 Left</option>
                            <option value="Rear7 Right">Rear7 Right</option>
                            <option value="Rear7 Left">Rear7 Left</option>
                            <option value="Rear8 Right">Rear8 Right</option>
                            <option value="Rear8 Left">Rear8 Left</option>
                        </select>
                    </div>
                    <div>
                        <label>Asign Date</label>
                        <input type="date" id="asign_date" class="form-control" name="asign_date" required/>
                    </div>
 
                    <button class="btn btn-primary" type="submit" style="margin-top: 20px;">Submit</button>
                </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include("footer.php"); ?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
    $('#locationSelect').change(function() {
        var locationId = $(this).val();

        // Clear the tire select box before making a request
        $('.tyerSelect').empty().append('<option value="">Select Tyer</option>');

        if (locationId) {
            $.ajax({
                url: '<?php echo base_url(); ?>/Admin/gettyerData',
                method: 'POST',
                data: {
                    location_id: locationId
                },
                dataType: 'json', // Expect a JSON response
                success: function(response) {
                    // Clear previous options
                    $('.tyerSelect').empty().append('<option value="">Select Tyer</option>');

                    // Populate new options
                    $.each(response, function(index, tire) {
                        $('.tyerSelect').append('<option value="' + tire.id + '">' + tire.tyer_sl_no + '</option>');
                    });
                },
                error: function(xhr, status, error) {
                    console.error('Error:', error);
                }
            });

        }
    });
});
</script>
