<?php include("header.php"); ?>
<div class="page-body-wrapper">
    <?php include("mainsidebar.php"); ?>
    <div class="page-body">
        <div class="container-fluid">
            <div class="page-title">
                <div class="row">
                    <div class="col-sm-6 p-0">
                        <h3>Vehicle Details</h3>
                    </div>
                </div>
            </div>
            <div class="container-fluid default-dashboard">
                <p></p>
                <div class="col-sm-12">
                    <div class="card">
                        <?php if (session()->getFlashdata('msg')): ?>
                            <div class="alert alert-success">
                                <?= session()->getFlashdata('msg') ?>
                            </div>
                        <?php endif; ?>
                        <div class="card-body">
                            <?php if(session()->getFlashdata('msg1')): ?>
    <div class="alert alert-warning">
        <?= session()->getFlashdata('msg1') ?>
    </div>
<?php endif; ?>


<div class="col-sm-6">
    <h3>Asign tyer excel upload</h3>
    Download sample Excel <a href="<?= base_url('sampleexcel/tyerasign.xlsx'); ?>">click here</a>.

<form action="<?= base_url('admin/upload_tyer_excel') ?>" method="post" enctype="multipart/form-data">
    <div class="uk-grid" uk-grid-small>
        <div>
           <div class="form-group">
        <label for="file">Upload Excel or CSV file:</label>
        <input type="file" class="form-control" name="file" id="file" accept=".xlsx, .xls, .csv" required>
    </div> 
        </div>
        <div>
           <label for="file">.</label> <br>
            <button type="submit" class="btn btn-primary">Upload</button>
        </div>
    </div>
</form>
 <div>
   <label for="file">.</label> <br>
    <button id="downloadExcel" class="btn btn-primary">Download Excel</button>
</div>
</div>


    <div class="table-responsive custom-scrollbar custom-scrollbar">
       <table class="display" id="row_create" style="width:100%">
            <thead>
                <tr>
                    <th>Sl.No</th>
                    <th>Vehicle Number</th>
                    <th>Front Right</th>
                    <th>Front Left</th>
                    <th>Rear1 Right</th>
                    <th>Rear1 Left</th>
                    <th>Rear2 Right</th>
                    <th>Rear2 Left</th>
                    <th>Rear3 Right</th>
                    <th>Rear3 Left</th>
                    <th>Rear4 Right</th>
                    <th>Rear4 Left</th>
                    <th>Rear5 Right</th>
                    <th>Rear5 Left</th>
                    <th>Rear6 Right</th>
                    <th>Rear6 Left</th>
                    <th>Rear7 Right</th>
                    <th>Rear7 Left</th>
                    <th>Rear8 Right</th>
                    <th>Rear8 Left</th>
                    <th>Action</th>
                    <th>Exchage Tyer</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $sr_no = 1;
                foreach ($vehicle as $vehic) { 
                    $positions = [
                        'Front Right' => '',
                        'Front Left' => '',
                        'Rear1 Right' => '',
                        'Rear1 Left' => '',
                        'Rear2 Right' => '',
                        'Rear2 Left' => '',
                        'Rear3 Right' => '',
                        'Rear3 Left' => '',
                        'Rear4 Right' => '',
                        'Rear4 Left' => '',
                        'Rear5 Right' => '',
                        'Rear5 Left' => '',
                        'Rear6 Right' => '',
                        'Rear6 Left' => '',
                        'Rear7 Right' => '',
                        'Rear7 Left' => '',
                        'Rear8 Right' => '',
                        'Rear8 Left' => '',
                    ];
                    
                    // Populate positions with data
                    foreach ($vehic['tyer_position'] as $position => $serial_no) {
                        $positions[$position] = $serial_no;
                    }
                ?>
                    <tr>
                        <td><?= $sr_no++; ?></td>
                        <td><?= $vehic['vehicle_no']; ?></td>
                        <td><?= $positions['Front Right']; ?></td>
                        <td><?= $positions['Front Left']; ?></td>
                        <td><?= $positions['Rear1 Right']; ?></td>
                        <td><?= $positions['Rear1 Left']; ?></td>
                        <td><?= $positions['Rear2 Right']; ?></td>
                        <td><?= $positions['Rear2 Left']; ?></td>
                        <td><?= $positions['Rear3 Right']; ?></td>
                        <td><?= $positions['Rear3 Left']; ?></td>
                        <td><?= $positions['Rear4 Right']; ?></td>
                        <td><?= $positions['Rear4 Left']; ?></td>
                        <td><?= $positions['Rear5 Right']; ?></td>
                        <td><?= $positions['Rear5 Left']; ?></td>
                        <td><?= $positions['Rear6 Right']; ?></td>
                        <td><?= $positions['Rear6 Left']; ?></td>
                        <td><?= $positions['Rear7 Right']; ?></td>
                        <td><?= $positions['Rear7 Left']; ?></td>
                        <td><?= $positions['Rear8 Right']; ?></td>
                        <td><?= $positions['Rear8 Left']; ?></td>
                        <td>
                             <?php if(in_array(25.1,$jobAssign)){ ?>
                            <!--<a href="javascript:void(0);" onClick="asign_tyer('<?= $vehic['id']; ?>');" class="btn btn-danger">Assign Tyer</a>-->
                            <a class="btn btn-danger" href="<?php echo site_url('admin/Asign_Tyers'); ?>/<?= $vehic['id']; ?>" >Assign Tyer</a>
                            <?php }?>
                            </td>
                        <td>
                            <?php if(in_array(25.2,$jobAssign)){ ?>
                            <a class="btn btn-danger" href="#modal-center<?= $vehic['id']; ?>" uk-toggle>Tyer Exchange</a>
                            <?php }?>
                                <div id="modal-center<?= $vehic['id']; ?>" class="uk-flex-top" uk-modal>
                                    <div class="uk-modal-dialog uk-modal-body uk-margin-auto-vertical">
                                
                                        <button class="uk-modal-close-default" type="button" uk-close></button>
                                        <form method="post" action="<?php echo base_url();?>/Admin/exchange_tyer_data">
                    <input type="hidden" class="form-control" name="vehicle_id" value="<?= $vehic['id']; ?>"/>
                    <div>
                        <label>Location</label>
                        <select id="locationSelect<?= $vehic['id'] ?>" name="location" class="form-control">
                            <option value="">Select location</option>
                            <?php foreach ($location as $loc) { ?>
                                <option value="<?= $loc->location_id; ?>"><?= $loc->location_name; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div id="locationDetails<?= $vehic['id'] ?>"></div>
                    <div> 
                        <label>Tyer Position</label>
                                                                                <select  class="form-control" name="tyer_position">
                                                                                    <option value="Front Right">Front Right</option>
                                                                                    <option value="Front Left">Front Left</option>
                                                                                    <option value="Rear1 Right">Rear1 Right</option>
                                                                                    <option value="Rear1 Left">Rear1 Left</option>
                                                                                    <option value="Rear2 Right">Rear2 Right</option>
                                                                                    <option value="Rear2 Left">Rear2 Left</option>
                                                                                    <option value="Rear3 Right">Rear3 Right</option>
                                                                                    <option value="Rear3 Left">Rear3 Left</option>
                                                                                    <option value="Rear4 Right">Rear4 Right</option>
                                                                                    <option value="Rear4 Left">Rear4 Left</option>
                                                                                    <option value="Rear5 Right">Rear5 Right</option>
                                                                                    <option value="Rear5 Left">Rear5 Left</option>
                                                                                    <option value="Rear6 Right">Rear6 Right</option>
                                                                                    <option value="Rear6 Left">Rear6 Left</option>
                                                                                    <option value="Rear7 Right">Rear7 Right</option>
                                                                                    <option value="Rear7 Left">Rear7 Left</option>
                                                                                    <option value="Rear8 Right">Rear8 Right</option>
                                                                                    <option value="Rear8 Left">Rear8 Left</option>
                                                                                </select>                 
                    </div>
                    
                    <button class="btn btn-primary" type="submit">Submit</button>
                </form>
                                        
                                       
                                    </div>
                                </div>
                        
                        
                        </td>
        
                    </tr>
                <?php } ?>
            </tbody>
            <tfoot>
                <tr>
                    <th>Sr.No</th>
                    <th>Vehicle Number</th>
                    <th>Front Right</th>
                    <th>Front Left</th>
                    <th>Rear1 Right</th>
                    <th>Rear1 Left</th>
                    <th>Rear2 Right</th>
                    <th>Rear2 Left</th>
                    <th>Rear3 Right</th>
                    <th>Rear3 Left</th>
                    <th>Rear4 Right</th>
                    <th>Rear4 Left</th>
                    <th>Rear5 Right</th>
                    <th>Rear5 Left</th>
                    <th>Rear6 Right</th>
                    <th>Rear6 Left</th>
                    <th>Rear7 Right</th>
                    <th>Rear7 Left</th>
                    <th>Rear8 Right</th>
                    <th>Rear8 Left</th>
                    <th>Action</th>
                    <th>Exchange Tyer </th>
                </tr>
            </tfoot>
        </table>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Container-fluid Ends-->
        </div>
    </div>
</div>
<?php include("footer.php"); ?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        $('#downloadExcel').click(function() {
            window.location.href = '<?= base_url("Admin/downloadExcelAsign_tyer") ?>';
        });
    });

</script>
<script>
    $(document).ready(function() {
        $('select[id^="locationSelect"]').change(function() {
            var locationId = $(this).val(); // Get selected location_id
            var vehicId = $(this).attr('id').replace('locationSelect', ''); // Get vehicle ID from select's ID
            
            // Send AJAX request
            $.ajax({
                url: '<?php echo base_url();?>/Admin/gettyer', // Replace with your server-side script URL
                method: 'POST',
                data: { location_id: locationId }, // Send location_id to server
                dataType: 'html', // Expect HTML response
                success: function(response) {
                    $('#locationDetails'+vehicId).html(response); // Update #locationDetails with HTML response
                },
                error: function(xhr, status, error) {
                    console.error('Error:', error);
                    // Handle error if necessary
                }
            });
        });
    });
</script>

<div id="modal-center" class="uk-flex-top" uk-modal>
    <div class="uk-modal-dialog uk-modal-body uk-margin-auto-vertical">
        <button class="uk-modal-close-default" type="button" uk-close></button>
        <form method="post" action="<?php echo base_url();?>/Admin/update_tyer_data">
            <input type="hidden" id="vehicle_id" class="form-control" name="vehicle_id" value=""/>
            <div>
                <label>Location</label>
                <select id="locationSelect<?= $vehic['id'] ?>" name="location" class="form-control">
                    <option value="">Select location</option>
                    <?php foreach ($location as $loc) { ?>
                        <option value="<?= $loc->location_id; ?>"><?= $loc->location_name; ?></option>
                    <?php } ?>
                </select>
            </div>
            <div  id="locationDetails<?= $vehic['id'] ?>" >
            
            <label>Select Tyer</label>
            <select class="form-control" id="single"  name="tyer_id" >
                <option value="">No Stock Available</option>
                <?php foreach ($tyer_data as $tyer) { ?>
                    <option value="<?= $tyer->id ?>"><?= $tyer->tyer_sl_no ?></option>
                <?php } ?>
            </select>
            </div>
            
            <div>
                <label>Tyer Position</label>
                                                                        <select  class="form-control" name="tyer_position">
                                                                            <option value="Front Right">Front Right</option>
                                                                            <option value="Front Left">Front Left</option>
                                                                            <option value="Rear1 Right">Rear1 Right</option>
                                                                            <option value="Rear1 Left">Rear1 Left</option>
                                                                            <option value="Rear2 Right">Rear2 Right</option>
                                                                            <option value="Rear2 Left">Rear2 Left</option>
                                                                            <option value="Rear3 Right">Rear3 Right</option>
                                                                            <option value="Rear3 Left">Rear3 Left</option>
                                                                            <option value="Rear4 Right">Rear4 Right</option>
                                                                            <option value="Rear4 Left">Rear4 Left</option>
                                                                            <option value="Rear5 Right">Rear5 Right</option>
                                                                            <option value="Rear5 Left">Rear5 Left</option>
                                                                            <option value="Rear6 Right">Rear6 Right</option>
                                                                            <option value="Rear6 Left">Rear6 Left</option>
                                                                            <option value="Rear7 Right">Rear7 Right</option>
                                                                            <option value="Rear7 Left">Rear7 Left</option>
                                                                            <option value="Rear8 Right">Rear8 Right</option>
                                                                            <option value="Rear8 Left">Rear8 Left</option>
                                                                        </select>                 
            </div>
            
            <button class="btn btn-primary" type="submit">Submit</button>
        </form>
    </div>
</div>
                                                        
<script type="text/javascript">
    function asign_tyer(id) {
        $("#vehicle_id").val(id);
        var modal = UIkit.modal("#modal-center");
        if (modal) {
            modal.show();
        }

        
    }
</script> 
