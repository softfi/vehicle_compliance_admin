<?php include("header.php"); 
foreach ($orderdtls as $orddtls){}
?>
<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css'>

<!-- Page Body Start-->
<div class="page-body-wrapper" style="background:#f9f9f9;">
    <?php include("mainsidebar.php"); ?>
    <div class="page-body">
        <div class="container-fluid">
            <div class="page-title">
                <div class="row">
                    <div class="col-sm-6 p-0">
                        <h3>Edit In House Maintenance</h3>
                    </div>
                    <div class="col-sm-6 p-0"></div>
                </div>
            </div>
        </div>
        <!-- Container-fluid starts-->
        <div class="container-fluid default-dashboard">
            <form name="add_name" id="add_inhouse_maintenance" action="<?php echo base_url();?>/Admin/update_inhouse" method="post">
                <div class="uk-card uk-card-body uk-card-small" style="border:solid 1px #ccc;">
                    <div class="uk-grid-small uk-child-width-expand@m uk-grid" uk-grid="">
                        <input type="hidden" value="<?=$orddtls->order_id;?>" name="oorder_id" />
                        <div class="uk-first-column">
                            <label>Select Vehicle</label>
                            <select name="vehicle" id="vehicle" class="form-control">
                                <option value="">Select vehicle</option>
                                <?php foreach ($vehicles as $vec) { ?>
                                    <option <?php if($vec->id==$orddtls->vehicle){echo "selected";}?> value="<?= $vec->id; ?>"> <?= $vec->vehicle_no; ?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <div>
                            <div id="vehicle-details">
                                <label>Driver</label>
                                <input type="text" name="driver" class="form-control" value="<?=$orddtls->driver_name?>" readonly />
                            </div>
                        </div>
                        <div>
                            <label>Date</label>
                            <input type="date" id="date" name="date" class="form-control" value="<?=$orddtls->date?>" >
                        </div>
                        <div>
                            <label>Time</label>
                            <input type="time" id="time" name="time" class="form-control" value="<?=$orddtls->time?>" >
                        </div>
                        <div>
                            <label>Remark</label>
                            <input type="text" name="invoiceno" id="invoiceno" class="form-control" value="<?=$orddtls->invoiceno?>">
                        </div>
                        <div>
                            <label>Location</label>
                            <select name="location" id="single" class="form-control">
                                <option value="">Select location</option>
                                <?php foreach ($location as $loc) { ?>
                                    <option <?php if($loc->location_id==$orddtls->location){echo "selected";}?>  value="<?= $loc->location_id; ?>"><?= $loc->location_name; ?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <div>
                            <label>Checked by</label>
                            <input type="text" name="check_by" class="form-control" value="<?=$orddtls->check_by?>" />
                        </div>
                    </div>
                </div>

                <p>&nbsp;</p>

                <div class="uk-grid-small uk-child-width-expand@m uk-grid" uk-grid="">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <table class="table table-bordered table-hover" id="dynamic_field">
                                    <?php 
                                    $i = 1;
                                    foreach ($orderdtls as $ordtls) { ?>
                                        <tr id="row<?= $i; ?>">
                                            <td><?= $i; ?></td>
                                            <td>
                                                <select class="form-control type-select">
                                                    <option value="1" >Service</option>
                                                    <option value="2" >Product</option>
                                                </select>
                                            </td>
                                            <td>
                                                <select name="items[]" id="items" class="form-control">
                                                    <option value="">Select items</option>
                                                    <?php foreach ($items as $item) { ?>
                                                        <option <?php if($ordtls->item == $item->id) echo "selected"; ?> value="<?= $item->id; ?>" data-price="<?= $item->amount; ?>"><?= $item->item_name; ?></option>
                                                    <?php } ?>
                                                </select>
                                            </td>
                                            <td>
                                                <input type="text" name="qty[]" placeholder="Enter quantity" value="<?= $ordtls->qty; ?>" class="form-control">
                                            </td>
                                            <td>
                                                <input type="text" name="price[]" placeholder="Enter Price" value="<?= $ordtls->price; ?>" class="form-control">
                                            </td>
                                            <td>
                                                <button type="button" name="remove" id="<?= $i; ?>" class="btn btn-danger btn_remove">X</button>
                                            </td>
                                        </tr>
                                    <?php $i++; } ?>
                                    
                                    <tr>
                                        <td>1</td>
                                        <td>
                                            <select class="form-control type-select">
                                                <option value="1">Service</option>
                                                <option value="2">Product</option>
                                            </select>
                                        </td>
                                        <td>
                                            <select name="items[]" id="items" class="form-control">
                                                <option value="">Select items</option>
                                                <?php foreach ($items as $item) { ?>
                                                    <option value="<?= $item->id; ?>" data-price="<?= $item->amount; ?>" ><?= $item->item_name; ?></option>
                                                <?php } ?>
                                            </select>
                                        </td>
                                        <td><input type="text" name="qty[]" placeholder="Enter quantity" class="form-control" /></td>
                                        <td><input type="text" name="price[]" placeholder="Enter Price" class="form-control" /></td>
                                        <td><button type="button" name="add" id="add" class="btn btn-primary">Add More</button></td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                
                <button class="btn btn-primary" type="submit">Submit</button>
            </form>
        </div>
        <!-- Container-fluid Ends-->
    </div>
    <!-- Footer start-->
    <?php include("footer.php"); ?>

<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js'></script>
<script src='https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js'></script>

<script>
    $(document).ready(function () {
        var i = 1;
        var addamount = 700;
        var itemsOptions = <?php echo json_encode(array_map(function($item) {
           return '<option data-price="' . $item->amount . '" value="' . $item->id . '">' . $item->item_name . '</option>';
        }, $items)); ?>;

        function updateRow(row) {
            var typeSelect = row.find('.type-select');
            typeSelect.change(function () {
                var selectedType = $(this).val();
                var inputs = row.find('input');
                var selects = row.find('select').not('.type-select');
                
                if (selectedType == "1") { // Service
                    inputs.attr('type', 'text').val('');
                    selects.replaceWith(function () {
                        return $('<input>', {
                            type: 'text',
                            name: $(this).attr('name'),
                            class: 'form-control',
                            placeholder: 'Enter value'
                        });
                    });
                } else { // Product
                    inputs.attr('type', 'text').val('');
                    selects.replaceWith(function () {
                        return $('<select>', {
                            name: $(this).attr('name'),
                            class: 'form-control'
                        }).append(itemsOptions.join(''));
                    });
                }
            });
        }

        updateRow($('#dynamic_field tr:first'));

        $("#add").click(function () {
            addamount += 700;
            console.log('amount: ' + addamount);
            i++;
            var newRow = $('<tr id="row' + i + '"><td>' + i + '</td><td><select class="form-control type-select"><option value="1">Service</option><option value="2">Product</option></select></td><td><select name="items[]" id="items" class="form-control"><option value="">Select items</option>' + itemsOptions.join('') + '</select></td><td><input type="text" name="qty[]" placeholder="Enter quantity" class="form-control"/></td><td><input type="text" name="price[]" placeholder="Enter Price" class="form-control"/></td><td><button type="button" name="remove" id="' + i + '" class="btn btn-danger btn_remove">X</button></td></tr>');
            $('#dynamic_field').append(newRow);
            updateRow(newRow);
        });

        $(document).on('click', '.btn_remove', function () {
            addamount -= 700;
            console.log('amount: ' + addamount);
            var button_id = $(this).attr("id");
            $('#row' + button_id).remove();
        });

        $("#submit").on('click', function (event) {
            var formdata = $("#add_name").serialize();
            console.log(formdata);

            event.preventDefault();

            $.ajax({
                url: "action.php",
                type: "POST",
                data: formdata,
                cache: false,
                success: function (result) {
                    alert(result);
                    $("#add_name")[0].reset();
                }
            });
        });
    });

    function pad(number) {
        return number < 10 ? '0' + number : number;
    }
    
    

    var now = new Date();
    var year = now.getFullYear();
    var month = pad(now.getMonth() + 1);
    var day = pad(now.getDate());

    var currentDate = year + '-' + month + '-' + day;

    var hours = pad(now.getHours());
    var minutes = pad(now.getMinutes());

    var currentTime = hours + ':' + minutes;

    document.getElementById('date').value = currentDate;
    document.getElementById('time').value = currentTime;
</script>

<script>
    $(document).ready(function () {
    // Function to update price based on selected item
    function updatePrice() {
        var selectedItem = $(this).find(":selected");
        var price = selectedItem.data('price'); // Get the price from data-price attribute
        var priceInput = $(this).closest('tr').find('input[name="price[]"]');
        priceInput.val(price); // Set the price input field value
    }

    // Call updatePrice function on item selection change
    $(document).on('change', 'select[name="items[]"]', updatePrice);
});
</script>
