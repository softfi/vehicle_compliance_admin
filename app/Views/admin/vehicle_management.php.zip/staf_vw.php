<?php include("header.php");?>
      <!-- Page Body Start-->
     <div class="page-body-wrapper">
        <?php include("mainsidebar.php"); ?>
        <?php foreach($singleuser as $singledata){}?>
       
        <div class="page-body">
          <div class="container-fluid">        
            <div class="page-title">
              <div class="row">
                <div class="col-sm-6 p-0">
                  <h3>Add Staf/ Driver </h3>
                </div>
                <div class="col-sm-6 p-0">
                                <?php if(in_array(15.1,$jobAssign)){ ?>
                    <button class="btn btn-primary uk-align-right" type="button" uk-toggle="target: #offcanvas-flip">Add Staff</button>
                    <?php }?>
                    <?php if(in_array(15.2,$jobAssign)){ ?>
                    <button class="btn btn-primary" style="float:right" type="button" data-bs-toggle="modal" data-bs-target="#uploadexcel" data-whatever="@getbootstrap">Upload EXCEL</button>
                     <?php }?>
<div id="offcanvas-flip" uk-offcanvas="flip: true; overlay: true">
    <div class="uk-offcanvas-bar uk-padding-remove uk-margin-remove uk-width-1-2@m" style="background:#fff;">

        <button class="uk-offcanvas-close" type="button" uk-close></button>
<div class="uk-card uk-card-body uk-card-default uk-card-samall">
    <form action="<?php echo base_url(); ?>/admin/Add_staf" enctype="multipart/form-data" method="post">
    <div class="modal-body">
        <div class="row">
            <div class="col-sm-6">
                <div class="form-group">
                    <label>Employee Name</label>
                    <input type="text" class="form-control" name="name" placeholder="Enter Your Name" value="<?= set_value('name'); ?>">
                    <?php if (isset($validation) && $validation->getError('name')): ?>
                        <span class="text-danger"><?= $validation->getError('name'); ?></span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="uk-margin">
                    <label>Employee Type</label>
                    <select class="form-control" name="user_type" aria-label="Select">
                        <option value="DRIVER" <?= set_select('user_type', 'Driver'); ?>>Driver</option>
                        <option value="STAFF" <?= set_select('user_type', 'Staff'); ?>>Staff Master</option>
                    </select>
                    <?php if (isset($validation) && $validation->getError('user_type')): ?>
                        <span class="text-danger"><?= $validation->getError('user_type'); ?></span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label>Date of Join</label>
                    <input type="date" class="form-control" name="doj" placeholder="Enter DOJ" value="<?= set_value('doj'); ?>">
                    <?php if (isset($validation) && $validation->getError('doj')): ?>
                        <span class="text-danger"><?= $validation->getError('doj'); ?></span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label>Salary</label>
                    <input type="text" class="form-control" name="salary" placeholder="Enter Salary" value="<?= set_value('salary'); ?>">
                    <?php if (isset($validation) && $validation->getError('salary')): ?>
                        <span class="text-danger"><?= $validation->getError('salary'); ?></span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-sm-6">
                <label>Upload Image</label>
                <input type="file" name="img" class="form-control">
                <?php if (isset($validation) && $validation->getError('img')): ?>
                    <span class="text-danger"><?= $validation->getError('img'); ?></span>
                <?php endif; ?>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label>Name in Bank</label>
                    <input type="text" class="form-control" name="name_bank" placeholder="Enter your name in bank" value="<?= set_value('name_bank'); ?>">
                    <?php if (isset($validation) && $validation->getError('name_bank')): ?>
                        <span class="text-danger"><?= $validation->getError('name_bank'); ?></span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label>A/c No</label>
                    <input type="number" class="form-control" name="ac_no" placeholder="Enter account number" value="<?= set_value('ac_no'); ?>">
                    <?php if(isset($validation)) { ?><span class="text-danger"><?= $error = $validation->getError('ac_no'); ?></span><?php } ?>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label>IFSC Code</label>
                    <input type="text" class="form-control" name="ifsc" placeholder="Enter your IFSC code" value="<?= set_value('ifsc'); ?>">
                    <?php if (isset($validation) && $validation->getError('ifsc')): ?>
                        <span class="text-danger"><?= $validation->getError('ifsc'); ?></span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label>DL</label>
                    <input type="file" class="form-control" name="driving_l" placeholder="Upload your DL picture" value="<?= set_value('driving_l'); ?>">
                    <?php if (isset($validation) && $validation->getError('driving_l')): ?>
                        <span class="text-danger"><?= $validation->getError('driving_l'); ?></span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label>DL Number</label>
                    <input type="text" class="form-control" name="dl_number" placeholder="Enter DL number " value="<?= set_value('dl_number'); ?>">
                    <?php if (isset($validation) && $validation->getError('dl_number')): ?>
                        <span class="text-danger"><?= $validation->getError('dl_number'); ?></span>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="col-sm-6">
                <div class="form-group">
                    <label>DL Expiry</label>
                    <input type="date" class="form-control" name="dl_expiry" placeholder="Enter DL expiry date" value="<?= set_value('dl_expiry'); ?>">
                    <?php if (isset($validation) && $validation->getError('dl_expiry')): ?>
                        <span class="text-danger"><?= $validation->getError('dl_expiry'); ?></span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label>Aadhaar Number</label>
                    <input type="text" class="form-control" name="aadhaar_no" placeholder=" Aadhaar Number" value="<?= set_value('aadhaar_no'); ?>">
                    <?php if (isset($validation) && $validation->getError('aadhaar_no')): ?>
                    <span class="text-danger"><?= $validation->getError('aadhaar_no'); ?></span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label>Aadhaar</label>
                    <input type="file" class="form-control" name="aadhaar" placeholder="Upload Aadhaar" value="<?= set_value('aadhaar'); ?>">
                    <?php if (isset($validation) && $validation->getError('aadhaar')): ?>
                        <span class="text-danger"><?= $validation->getError('aadhaar'); ?></span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label>Contact No.</label>
                    <input type="tel" class="form-control" name="tel" placeholder="Enter your Contact Number" value="<?= set_value('tel'); ?>">
                    <?php if (isset($validation) && $validation->getError('tel')): ?>
                        <span class="text-danger"><?= $validation->getError('tel'); ?></span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label>Father's Name</label>
                    <input type="text" class="form-control" name="fathers_name" placeholder="Enter your Father's Name" value="<?= set_value('fathers_name'); ?>">
                    <?php if (isset($validation) && $validation->getError('fathers_name')): ?>
                        <span class="text-danger"><?= $validation->getError('fathers_name'); ?></span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label>Spouse Name</label>
                    <input type="text" class="form-control" name="spouse_name" placeholder="Enter your Spouse Name" value="<?= set_value('spouse_name'); ?>">
                    <?php if (isset($validation) && $validation->getError('spouse_name')): ?>
                        <span class="text-danger"><?= $validation->getError('spouse_name'); ?></span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label>Date of Birth</label>
                    <input type="date" class="form-control" name="dob" placeholder="Enter your Date of Birth" value="<?= set_value('dob'); ?>">
                    <?php if (isset($validation) && $validation->getError('dob')): ?>
                        <span class="text-danger"><?= $validation->getError('dob'); ?></span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label>Family Contact No.</label>
                    <input type="tel" class="form-control" name="family_contact" placeholder="Enter your Family Contact Number" value="<?= set_value('family_contact'); ?>">
                    <?php if (isset($validation) && $validation->getError('family_contact')): ?>
                        <span class="text-danger"><?= $validation->getError('family_contact'); ?></span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label>Blood Group</label>
                    <select class="form-control" name="blood_group" aria-label="Select">
                        <option value="O+" <?= set_select('blood_group', 'O+'); ?>>O+</option>
                        <option value="O-" <?= set_select('blood_group', 'O-'); ?>>O-</option>
                        <option value="A+" <?= set_select('blood_group', 'A+'); ?>>A+</option>
                        <option value="A-" <?= set_select('blood_group', 'A-'); ?>>A-</option>
                        <option value="B+" <?= set_select('blood_group', 'B+'); ?>>B+</option>
                        <option value="B-" <?= set_select('blood_group', 'B-'); ?>>B-</option>
                        <option value="AB+" <?= set_select('blood_group', 'AB+'); ?>>AB+</option>
                        <option value="AB-" <?= set_select('blood_group', 'AB-'); ?>>AB-</option>
                    </select>
                    <?php if (isset($validation) && $validation->getError('blood_group')): ?>
                        <span class="text-danger"><?= $validation->getError('blood_group'); ?></span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label>Opening Balance</label>
                   <input type="text" name="opening_balance" class="form-control" />
                    <?php if (isset($validation) && $validation->getError('opening_balance')): ?>
                        <span class="text-danger"><?= $validation->getError('opening_balance'); ?></span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="form-group">
                    <label>Address</label>
                   
                    
                    <label for="location">Location</label>
                                    <select name="address" id="location" class="form-control">
                                        <option value="">Select location</option>
                                        <?php foreach ($location as $loc): ?>
                                            <option value="<?= $loc->location_id; ?>"><?= $loc->location_name; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    
                    <?php if (isset($validation) && $validation->getError('address')): ?>
                        <span class="text-danger"><?= $validation->getError('address'); ?></span>
                    <?php endif; ?>
                </div>
            </div>
            
        </div>
    </div>
    <p></p>
    <button type="submit" class="btn btn-primary">Submit</button>
</form>
</div>

    </div>
</div>


                </div>
          </div>
          <!-- Container-fluid starts-->
          <div class="container-fluid default-dashboard">
            <div class="row">
      	<div class="col-xs-12">
        <div class="card ">
       
</div>
                  </ol>
                </div>
              </div>
            </div>
          </div>
          <!-- Container-fluid starts-->
          
          <!-- Container-fluid starts-->
          <div class="container-fluid default-dashboard">
        
        
        
        
           
                        <div class="uk-grid-small uk-child-width-expand@m" uk-grid>
                        
                        
                            <div>
                        <div class="uk-card uk-card-body uk-card-default uk-card-small">
                        	
                            <div class="table-responsive">
                                   <table class="display" id="row_create" style="width:100%">
    <thead>
        <tr>
            <th>Sl no</th>
            <th>User Type</th>
            <th>Name</th>
            <th>Date of Join</th>
            <th>staf code</th>
            <th>Name in Bank</th>
            <th>A/c No</th>
            <th>IFSC Code</th>
            <th>DL image</th>
            <th>Dl Number</th>
            <th>DL Expiry</th>
            <th>Aadhaar</th>
            <th>Salary</th>
            <th>Contact No.</th>
            <th>Spouse Name</th>
            <th>DOB</th>
            <th>Family Contact No.</th>
            <th>Blood Group</th>
            <th>Address</th>
            <th>Image</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php 
        $i=1;
        foreach ($allstaf as $staf) { ?>
        <tr>
            <td><?=$i++;?></td>
            <td><?=$staf->user_type?></td>
            <td><?=$staf->name?></td>
            <td><?=date('d/m/Y', strtotime($staf->doj))?></td>
             <td><?=$staf->staff_code?></td>
            <td><?=$staf->name_bank?></td>
            <td><?=$staf->ac_no?></td>
            <td><?=$staf->ifsc?></td>
            <td><img src="<?php echo base_url(); ?>/<?=$staf->driving_l?>"/> </td>
            <td><?=$staf->dl_number?></td>
            <td><?=date('d/m/Y', strtotime($staf->dl_expiry))?></td>
            <td><img src="<?php echo base_url();?>/uploads/<?=$staf->aadhaar?>" width="50px"></td>
            <td><?=$staf->salary?></td>
            <td><?=$staf->tel?></td>
            <td><?=$staf->spouse_name?></td>
            <td><?=date('d/m/Y', strtotime($staf->dob))?></td>
            <td><?=$staf->family_contact?></td>
            <td><?=$staf->blood_group?></td>
            <td><?=$staf->location_name?></td>
            <td><img src="<?=base_url($staf->img)?>" alt="Image" style="width:50px;height:50px;"></td>
            <td>
                <div class="uk-button-group">
            <?php if(in_array(15.3,$jobAssign)){ ?>
            <a href="javascript:void(0);" onClick="editvehicle('<?= $staf->id ; ?>');" class="uk-button uk-button-small uk-button-secondary">edit</a>
            <?php }?>
            <?php if(in_array(15.4,$jobAssign)){ ?>
            <a href="<?= base_url('Admin/DeleteStaff/'.$staf->id); ?>" onclick="return confirm('Are you sure you want to delete this item?');" class="uk-button uk-button-small uk-button-danger">delete</a>
            <?php }?>
            
            <a href="javascript:void(0);" onClick="printvehicle('<?= $staf->id ; ?>');" class="uk-button uk-button-small uk-button-primary">Print</a>
        </div>
            </td>
        </tr>
        <?php } ?>
    </tbody>
       <tfoot>
        <tr>
           <th>Sl no</th>
            <th>User Type</th>
            <th>Name</th>
            <th>Date of Join</th>
            <th>staf code</th>
            <th>Name in Bank</th>
            <th>A/c No</th>
            <th>IFSC Code</th>
            <th>DL image</th>
            <th>Dl Number</th>
            <th>DL Expiry</th>
            <th>Aadhaar</th>
            <th>Salary</th>
            <th>Contact No.</th>
            <th>Spouse Name</th>
            <th>DOB</th>
            <th>Family Contact No.</th>
            <th>Blood Group</th>
            <th>Address</th>
            <th>Image</th>
            <th>Actions</th>
        </tr>
    </tfoot>	
</table>
                                
                                
                                
                               
                            </div>
                            </div>
                            </div>
                        </div>
                        <!-- END Mini Top Stats Row -->

                        
                    </div>
                    <!-- END Page Content -->

 <form name="frm_deleteBanner" id="frm_deleteBanner" action="<?php echo base_url();?>/admin/deleteSubadmin" method="post">
 <input type="hidden" name="operation" id="operation" value="">
 <input type="hidden" name="user_id" id="user_id" value="">
 </form>
<script type="text/javascript">
function deleteRecord(id){
	$("#operation").val('delete');
	$("#user_id").val(id);
	var conf=confirm("Are you sure want to delete this Subadmin");
	if(conf){
	   $("#frm_deleteBanner").submit();
	}
}
</script> 



    <script>
        UIkit.modal('#modal-center<?= session()->getFlashdata('uid') ?>').show();
    </script>

        
        
        
        
  <?php if (isset($validation)){ ?>      
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            UIkit.offcanvas('#offcanvas-flip').show();
        });
    </script> 
       <?php } ?> 
       
       
       
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
    function editvehicle(id) {
        $.ajax({
            url: '<?php echo base_url(); ?>/Admin/edit_staff', // Replace with your controller method URL
            type: 'POST',
            data: { staff_id: id },
            success: function(response) {
                // Assuming 'response' is a JSON object containing vehicle data
                $('#edit_staff_form').html(response); // Populate your form with the response data
                
                // Open the UIkit off-canvas
                UIkit.offcanvas('#edit_vehicle').show();
            },
            error: function(xhr, status, error) {
                console.error(error);
            }
        });
    }
</script>

<script>
    function printvehicle(id) {
        // alert(id);
        $.ajax({
            url: '<?php echo base_url(); ?>/Admin/PrintStaff',
            type: 'POST',
            data: { staff_id: id },
            success: function(response) {
                $('#print_staff_form').html(response);
                UIkit.offcanvas('#print_vehicle').show();
            },
            error: function(xhr, status, error) {
                console.error(error);
            }
        });
    }
</script>


 <div class="modal fade" id="uploadexcel" tabindex="-1" role="dialog" aria-labelledby="exampleModalgetbootstrap" aria-hidden="true">
                      <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-body">
                                <a href="<?= base_url('sampleexcel/staffexcell.xlsx') ?>">click here </a> to download sample
                            <form action="<?= base_url('Admin/upload_staff_excel') ?>" method="post" enctype="multipart/form-data">
                                <label for="file">Choose CSV or Excel File:</label><br>
                                <input type="file" name="file" id="file" class="form-control" accept=".csv, .xlsx">
                                <p><br></p>
                                <button  class="btn btn-primary" type="submit">Upload</button>
                            </form>
                            </div>
                        </div>
                    </div>
                </div>
                
                
    
    
    

<div id="edit_vehicle" uk-offcanvas="flip: true; overlay: true">
    <div class="uk-offcanvas-bar uk-padding-remove uk-margin-remove uk-width-1-2" style="background:#fff">

        <button class="uk-offcanvas-close" type="button" uk-close></button>
        <div class="uk-card uk-card-body uk-card-small uk-card-default">
            <div id="edit_staff_form"></div>
        </div>
    </div>
</div>

<div id="print_vehicle" uk-offcanvas="flip: true; overlay: true">
    <div class="uk-offcanvas-bar uk-padding-remove uk-margin-remove uk-width-1-2" style="background:#fff">

        <button class="uk-offcanvas-close" type="button" uk-close></button>
        <div class="uk-card uk-card-body uk-card-small uk-card-default">
            <div id="print_staff_form"></div>
        </div>
    </div>
</div>


        
        
        
        
            </div>
         </div>
        </div>
    </div>
        <!-- footer start-->
       <?php include("footer.php");?>
