<?php include("header.php");?>
<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css'>
      <!-- Page Body Start-->
      <div class="page-body-wrapper" style="background:#f9f9f9;">
        <?php include("mainsidebar.php"); ?>
        <div class="page-body">
          <div class="container-fluid">        
            <div class="page-title">
              <div class="row">
                <div class="col-sm-6 p-0">
                  <h3>Asign Driver </h3>
                </div>
                <div class="col-sm-6 p-0">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">
                        <svg class="stroke-icon">
                          
                        </svg></a></li>
                    <li class="breadcrumb-item">Dashboard</li>
                    <li class="breadcrumb-item active">Asign Driver      </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
          <!-- Container-fluid starts-->
          <div class="container-fluid default-dashboard">
              <div class="uk-child-width-expand uk-grid-small" uk-grid>
                  <div class="uk-width-1-4@m">
                      <?php if(session()->getFlashdata('msg')):?>
                                                <div class="alert alert-warning">
                                                <?= session()->getFlashdata('msg') ?>
                                                </div>
                                            <?php endif;?>
                       <div class="uk-card uk-card-body uk-card-default uk-card-small">
                <form action="<?php echo base_url(); ?>/Admin/insert_driver_asignment" method="post">
                   <div class="form-group">
                <label for="vehicle_no">Vehicle No:</label>
                <select class="form-control" name="vehicle_no" id="vehicle_no" required>
                    <option value="">Select Vehicle No.</option>
                    <?php foreach ($vehicles as $vehicle): ?>
                        <option value="<?= $vehicle->id; ?>"><?= $vehicle->vehicle_no; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label for="driver">Driver:</label>
                <select class="form-control" name="driver" id="driver" required>
                    <option value="">Select Driver</option>
                    <?php foreach ($drivers as $driver){ 
                        if($driver->user_type=='DRIVER'){ ?>
                            <option value="<?= $driver->id; ?>"><?= $driver->name; ?> (<?= $driver->staff_code; ?>)</option>
                    <?php }} ?>
                </select>
            </div>
            
            <div class="form-group">
                <label for="from_date">From Date:</label>
                <input type="date" class="form-control" name="from_date" id="from_date" required>
            </div>
                    <div id="openinghsd">
                    <div class="form-group">
                        <label for="opening_hsd">Opening HSD:</label>
                        <input type="text" class="form-control" name="opening_hsd" id="opening_hsd" required>
                    </div>

                    <div class="form-group">
                        <label for="opening_km">Opening KM:</label>
                        <input type="text" class="form-control" name="opening_km" id="opening_km" required>
                    </div>
                    
                    </div>
                    <div class="form-group">
                        <label for="to_date">To Date:</label>
                        <input type="date" class="form-control" name="to_date" id="to_date" >
                    </div>
            
                    <div class="form-group">
                        <label for="closing_hsd">Closing HSD:</label>
                        <input type="text" class="form-control" name="closing_hsd" id="closing_hsd" >
                    </div>
            
                    <div class="form-group">
                        <label for="closing_km">Closing KM:</label>
                        <input type="text" class="form-control" name="closing_km" id="closing_km" >
                    </div>
                    <?php if(in_array(8.1,$jobAssign)){ ?>
                    <button type="submit" class="btn btn-primary">Submit</button>
                    <?php }?>
                </form>
            </div>
                  </div>
                  <div>
                     <div class="uk-card uk-card-body uk-card-default uk-card-small uk-margin-bottom">
        
        <form id="filterForm" action="<?php echo base_url(); ?>/Admin/Driver_Assignment" method="post">
            <div class="uk-grid-small uk-child-width-expand" uk-grid>
            <div class="form-group">
                <label for="filter-year">Year:</label>
                <select class="form-control" name="year" id="filter-year" required>
                    <option value="">Select Year</option>
                    <?php
                    if(!empty($year)){
                       $currentYear=$year;
                    }else{
                    $currentYear = date("Y");
                    }
                    for ($year = $currentYear; $year >= 2000; $year--) {
                        
                        $selected = $year == $currentYear ? 'selected' : '';
                        echo "<option value=\"$year\" $selected>$year</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label for="filter-month">Month:</label>
                <select class="form-control" name="month" id="filter-month" required>
                    <option value="">Select Month</option>
                    <?php
                    
                     if(!empty($month)){
                       $currentMonth=$month;
                    }else{
                     $currentMonth = date("n");
                    }
                    
                    
                    
                    $months = [
                        1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April',
                        5 => 'May', 6 => 'June', 7 => 'July', 8 => 'August',
                        9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December'
                    ];
                    foreach ($months as $num => $name) {
                        $selected = $num == $currentMonth ? 'selected' : '';
                        echo "<option value=\"$num\" $selected>$name</option>";
                    }
                    ?>
                </select>
            </div>
            <div>
                <label class="uk-width-1-1@m">.</label>
                <?php if(in_array(8.2,$jobAssign)){ ?>
                <button type="submit" class="btn btn-primary">Filter</button>
                <?php }?>
            </div>
               <div class="form-group">
               <label>.</label><br>
               <button class="btn btn-primary" type="button" onclick="downloadExcel()">Download Excel</button>
               </div>
            </div>
        </form>
    </div>
<div class="uk-card uk-card-body uk-card-default uk-card-small">
    <div class="table-responsive custom-scrollbar custom-scrollbar">
         <table class="display" id="row_create" style="width:100%">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Vehicle Number</th>
                    <th>Driver Name</th>
                    <th>From Date</th>
                    <th>Opening HSD</th>
                    <th>Opening KM</th>
                    <th>To Date</th>
                    <th>Closing HSD</th>
                    <th>Closing KM</th>
                    
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($drivers_asignment as $record): ?>
                    <tr>
                        <td><?= $record->id; ?></td>
                        <td><?= $record->vehicle_number; ?></td>
                        <td>
                            <?= htmlspecialchars($record->driver_name); ?> (<?= htmlspecialchars($record->driver_code); ?>)
                        </td>
                        <td><?= $record->from_date; ?></td>
                        <td><?= $record->opening_hsd; ?></td>
                        <td><?= $record->opening_km; ?></td>
                        <td><?= $record->to_date; ?></td>
                        <td><?= $record->closing_hsd; ?></td>
                        <td><?= $record->closing_km; ?></td>
                        
                        <td>
                            <!--<button class="btn btn-primary" uk-toggle="target: #editModal" onclick="openEditModal(<?= $record->id; ?>)">Edit</button>-->
                            <?php if(in_array(8.3,$jobAssign)){ ?>
                            <a class="btn btn-primary"  href="<?php echo base_url(); ?>/Admin/Edit_Driver_Assignment/<?= $record->id; ?>">Edit </a>
                            <?php }?>
                        </td>
                        <td>
                            <?php if(in_array(8.4,$jobAssign)){ ?>
                            <button class="btn  btn-danger" onclick="deleteRecord(<?= $record->id; ?>)">Delete</button>
                            <?php }?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Edit Modal -->
<div id="editModal" uk-modal>
    <div class="uk-modal-dialog uk-modal-body">
        <button class="uk-modal-close-default" type="button" uk-close></button>
        <h2 class="uk-modal-title">Edit Driver Assignment</h2>
        <form id="editForm" action="<?php echo base_url(); ?>/Admin/update_driver_asignment" method="post">
            <input type="hidden" name="id" id="edit-id">
            <div class="uk-margin">
                <label for="edit-vehicle_no">Vehicle No:</label>
                <select class="form-control" name="vehicle_no" id="edit-vehicle_no" required>
                    <option value="">Select Vehicle No.</option>
                    <?php foreach ($vehicles as $vehicle): ?>
                        <option value="<?= $vehicle->id; ?>"><?= $vehicle->vehicle_no; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="uk-margin">
                <label for="edit-driver">Driver:</label>
                <select class="form-control" name="driver" id="edit-driver" required>
                    <option value="">Select Driver</option>
                    <?php foreach ($drivers as $driver): ?>
                        <?php if ($driver->user_type == 'DRIVER'): ?>
                            <option value="<?= $driver->id; ?>"><?= $driver->name; ?></option>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="uk-margin">
                <label for="edit-from_date">From Date:</label>
                <input type="date" class="uk-input" name="from_date" id="edit-from_date" required>
            </div>
            <div class="uk-margin">
                <label for="edit-opening_hsd">Opening HSD:</label>
                <input type="number" class="uk-input" name="opening_hsd" id="edit-opening_hsd" required>
            </div>
            <div class="uk-margin">
                <label for="edit-opening_km">Opening KM:</label>
                <input type="number" class="uk-input" name="opening_km" id="edit-opening_km" required>
            </div>
            <div class="uk-margin">
                <label for="edit-to_date">To Date:</label>
                <input type="date" class="uk-input" name="to_date" id="edit-to_date" required>
            </div>
            <div class="uk-margin">
                <label for="edit-closing_hsd">Closing HSD:</label>
                <input type="number" class="uk-input" name="closing_hsd" id="edit-closing_hsd" required>
            </div>
            <div class="uk-margin">
                <label for="edit-closing_km">Closing KM:</label>
                <input type="number" class="uk-input" name="closing_km" id="edit-closing_km" required>
            </div>
            <button type="submit" class="uk-button uk-button-primary">Submit</button>
        </form>
    </div>
</div>

<script>
// JavaScript to open and close the edit modal
function openEditModal(id) {
    // Populate the form with existing data
    var record = <?php echo json_encode($drivers_asignment); ?>.find(record => record.id == id);
    document.getElementById('edit-id').value = record.id;
    document.getElementById('edit-vehicle_no').value = record.vehicle_no;
    document.getElementById('edit-driver').value = record.driver;
    document.getElementById('edit-from_date').value = record.from_date;
    document.getElementById('edit-opening_hsd').value = record.opening_hsd;
    document.getElementById('edit-opening_km').value = record.opening_km;
    document.getElementById('edit-to_date').value = record.to_date;
    document.getElementById('edit-closing_hsd').value = record.closing_hsd;
    document.getElementById('edit-closing_km').value = record.closing_km;
}

function deleteRecord(id) {
    if (confirm('Are you sure you want to delete this record?')) {
        window.location.href = '<?php echo base_url(); ?>/Admin/delete_driver_asignment/' + id;
    }
}
function downloadExcel() {
    let form = document.getElementById('filterForm');
    form.action = "<?php echo base_url('Admin/downloadExcel'); ?>";
    form.submit();
}


</script>



  
    
    
                  </div>
              </div>
           
          </div>
          <!-- Container-fluid Ends-->
        </div>
        <!-- footer start-->
       <?php include("footer.php");?>
       
       
   
