<?php include("header.php"); ?>
<div class="page-body-wrapper">
    <?php include("mainsidebar.php"); ?>
    <div class="page-body">
        <div class="container-fluid">        
            <div class="page-title">
                <div class="row">
                    <div class="col-sm-6 p-0">
                        <h3>Repair Report</h3>
                    </div>
                </div>
            </div>
        </div>

        <div class="container-fluid">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <!-- Add the 'table-searchable' class for search functionality -->
                        <table class="display table table-striped table-bordered" id="row_create" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Sl.No</th>
                                    <th>Tyre Sl. No</th>
                                    <th>Bill No</th>
                                    <th>Status</th>
                                    <th>Exchange Vendor Name</th>
                                    <th>Remark</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $i = 1;
                                foreach ($tyer_data as $report) {
                                    // Assign the appropriate label based on the status
                                    $statusLabel = '';
                                    if ($report->status == 3) {
                                        $statusLabel = 'Trash';
                                    } elseif ($report->status == 4) {
                                        $statusLabel = 'Repair';
                                    } elseif ($report->status == 5) {
                                        $statusLabel = 'Exchange';
                                    }
                                ?>
                                    <tr>
                                        <td><?= $i++ ?></td>
                                        <td><?= $report->tyer_sl_no ?></td>
                                        <td><?= $report->bill_no ?></td>
                                        <td><?= $statusLabel ?></td> <!-- Display the status label -->
                                        <td><?= $report->exchange_vendorname ?></td>
                                        
                                        <td><?= $report->remark ?></td>
                                    </tr>   
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add DataTables JS and CSS -->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

<script>
    $(document).ready(function() {
        // Initialize DataTables with search functionality
        $('#row_create').DataTable({
            "searching": true,  // Enable search
            "paging": true,     // Enable pagination
            "info": true        // Show information summary
        });
    });
</script>

<?php include("footer.php"); ?>
