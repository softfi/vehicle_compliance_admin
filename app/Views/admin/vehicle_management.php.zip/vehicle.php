<?php include("header.php");?>
      <!-- Page Body Start-->
      <div class="page-body-wrapper">
        <?php include("mainsidebar.php"); ?>
       
        <div class="page-body">
          <div class="container-fluid">        
            <div class="page-title">
              <div class="row">
                <div class="col-sm-6 p-0">
                  <h3>Vehicle 
             
                  
                  </h3>
                   
                </div>
                <div class="col-sm-6 p-0">
                <?php if(in_array(13.2,$jobAssign)){ ?>
                 <button class="btn btn-warning" style="float:right; margin-right:10px;"  type="button" uk-toggle="target: #addnewvehicle">Add New Vehicle</button>
                 <?php }?>
                 <?php if(in_array(13.1,$jobAssign)){ ?>
                 <button class="btn btn-primary" style="float:right" type="button" data-bs-toggle="modal" data-bs-target="#uploadexcel" data-whatever="@getbootstrap">Upload EXCEL</button>
                 <?php }?> 
                 <?php if(in_array(13.3,$jobAssign)){ ?>
                 <a href="<?php echo base_url(); ?>/sampleexcel/vehicle_excel-ok.xlsx" target="_blank" class="btn btn-primary" style="float:right" type="button" > sample excel</a>
                 <?php }?>
            </div>
          </div
          
          </div>
          <!-- Container-fluid starts-->
          <div class="container-fluid default-dashboard">
              <p></p>
             

<div class="col-sm-12">
                <div class="card">
                  <?php if(session()->getFlashdata('msg')):?>
                                                <div class="alert alert-success">
                                                <?= session()->getFlashdata('msg') ?>
                                                </div>
                                            <?php endif;?>
                                            
                  <div class="card-body"> 
                    <div class="table-responsive custom-scrollbar custom-scrollbar">
                     <table class="display" id="row_create" style="width:100%">
    <thead>
        <tr>
            <th>Sr.No</th>
            <th>Vehicle Number</th>
            <th>Chassis No.</th>
            <th>Engine No.</th>
            <th>Fitness Expiry Date</th>
            <th>Fitness Amount</th>
            <th>Tax Expiry Date</th>
            <th>Tax Amount</th>
            <th>Insurance Company</th>
            <th>Insurance Expiry Date</th>
            <th>Ins Amount</th>
            <th>Permit Expiry Date</th>
            <th>Permit Amount</th>
            
            <th>National Permit Expiry Date</th>
            <th>National Permit Amount</th>
            
            <th>Finance</th>
            <th>Deduct Amount</th>
            <th>EMI Account</th>
            <th>Horse Make</th>
            <th>Horse Model</th>
            <th>Horse Rate</th>
            <th>Dala Rate</th>
            <th>Dala Make</th>
            <th>RTO Expenses</th>
            <th>AMC</th>
            <th>AMC Amount</th>
            <th>AMC Frequency</th>
            <th>AMC Expiry</th>
            <th>PUCC</th>
            <th>PUCC Amount</th>
            <th>I3MS Expiry</th>
            <th>I3MS Recharge</th>
            <th>Khanij Expiry</th>
            <th>Khanij amount</th>
            <th>Remark</th>
            <th>Document</th>
            <th>Location</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody> 
       <?php 
$sr_no = 1;
foreach ($vehicle as $vehic) { ?>
    <tr>
        <td><?= $sr_no++; ?></td>
        <td><?= $vehic->vehicle_no; ?></td>
        <td><?= $vehic->chassis_no; ?></td>
        <td><?= $vehic->engine_no; ?></td>
        <td><?= (new DateTime($vehic->fitness_exp_date))->format('d-m-Y'); ?></td>
        <td><?= $vehic->fitness_amount; ?></td>
        <td><?= (new DateTime($vehic->tax_exp_date))->format('d-m-Y'); ?></td>
        <td><?= $vehic->road_tax_amount; ?></td>
        <td><?= $vehic->ins_company; ?></td>
        <td><?= (new DateTime($vehic->ins_exp_date))->format('d-m-Y'); ?></td>
        <td><?= $vehic->insurance_amount; ?></td>
        <td><?= (new DateTime($vehic->permit_exp_date))->format('d-m-Y'); ?></td>
        <td><?= $vehic->permit_amount; ?></td>
        <td><?= (new DateTime($vehic->npermit_exp_date))->format('d-m-Y'); ?></td>
        <td><?= $vehic->npermit_amount; ?></td>
        <td><?= $vehic->finance; ?></td>
        <td><?= $vehic->deduct_amount; ?></td>
        <td><?= $vehic->emi_account; ?></td>
        <td><?= $vehic->horse_make; ?></td>
        <td><?= $vehic->horse_model; ?></td>
        <td><?= $vehic->horse_rate; ?></td>
        <td><?= $vehic->dala_rate; ?></td>
        <td><?= $vehic->dala_make; ?></td>
        <td><?= $vehic->rto_expenses; ?></td>
        <td><?= $vehic->amc; ?></td>
        
        <td><?= $vehic->amc_amount; ?></td>
        <td><?= $vehic->amc_frequancy; ?></td>
        <td><?= (new DateTime($vehic->amc_expary))->format('d-m-Y'); ?></td>
        <td><?= $vehic->pucc; ?></td>
        <td><?= $vehic->pucc_amount; ?></td>
        <td><?= (new DateTime($vehic->i3ms_expary))->format('d-m-Y'); ?></td>
        <td><?= $vehic->i3ms_recharge; ?></td>
        <td><?= (new DateTime($vehic->khanij_expiri))->format('d-m-Y'); ?></td>
        <td><?= $vehic->khanij_amount; ?></td>
        <td><?= $vehic->remark; ?></td>
        <td><a href="<?= base_url() . '/' . $vehic->document; ?>">Document</a></td>
        <td><?= $vehic->location_name; ?> </td>
        <td>
            <div class="btn-group">
                <?php if(in_array(13.4,$jobAssign)){ ?>
                <a class="btn btn-primary" href="javascript:void(0);" onClick="editvehicle('<?= $vehic->id ; ?>');">Edit</a> 
                <?php }?>
              <?php if(in_array(13.5,$jobAssign)){ ?>
                <a class="btn btn-danger" href="<?= base_url('Admin/DeleteVehicle/' . $vehic->id); ?>" onclick="return confirm('Are you sure you want to delete this item?');">Delete</a>
                <?php }?>
            </div>
        </td>
    </tr>
<?php } ?>

    </tbody>
    <tfoot>
        <tr>
          <th>Sr.No</th>
            <th>Vehicle Number</th>
            <th>Chassis No.</th>
            <th>Engine No.</th>
            <th>Fitness Expiry Date</th>
            <th>Fitness Amount</th>
            <th>Tax Expiry Date</th>
            <th>Tax Amount</th>
            <th>Insurance Company</th>
            <th>Insurance Expiry Date</th>
            <th>Ins Amount</th>
            <th>Permit Expiry Date</th>
            <th>Permit Amount</th>
            <th>National Permit Expiry Date</th>
            <th>National Permit Amount</th>
            <th>Finance</th>
            <th>Deduct Amount</th>
            <th>EMI Account</th>
            <th>Horse Make</th>
            <th>Horse Model</th>
            <th>Horse Rate</th>
            <th>Dala Rate</th>
            <th>Dala Make</th>
            <th>RTO Expenses</th>
            <th>AMC</th>
            <th>AMC Amount</th>
            <th>AMC Frequency</th>
            <th>AMC Expiry</th>
            <th>PUCC</th>
            <th>PUCC Amount</th>
            <th>I3MS Expiry</th>
            <th>I3MS Recharge</th>
            <th>Khanij Expiry</th>
            <th>Khanij Amount</th>
            <th>Remark</th>
            <th>Document</th>
            <th>Action</th>
        </tr>
    </tfoot>
</table>

                    </div>
                  </div>
                  </div>
                  </div>

   </div>
        
      </div>
          </div>
          <!-- Container-fluid Ends-->
        </div>
        
        
        
        <div class="modal fade" id="uploadexcel" tabindex="-1" role="dialog" aria-labelledby="exampleModalgetbootstrap" aria-hidden="true">
                      <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-body">
                            <form action="<?= base_url('Admin/upload') ?>" method="post" enctype="multipart/form-data">
                                <label for="file">Choose CSV or Excel File:</label><br>
                                <input type="file" name="file" id="file" class="form-control" accept=".csv, .xlsx">
                                <p><br></p>
                                <button  class="btn btn-primary" type="submit">Upload</button>
                            </form>
                            </div>
                        </div>
                    </div>
                </div>
                
                
                
                
                
        
        
         <div id="addnewvehicle" uk-offcanvas="flip: true; overlay: true">
    <div class="uk-offcanvas-bar uk-padding-remove uk-margin-remove uk-width-1-2@m " >

        <button class="uk-offcanvas-close" type="button" uk-close></button>
<div class="uk-card uk-card-body uk-card-default uk-card-small ">
    
     <form action="<?php echo base_url(); ?>/Admin/Insertvehicle" enctype="multipart/form-data" method="post">
                        <div class="modal-body">
                            <div class="uk-child-width-1-2@m uk-grid-small" uk-grid>
                            <div class="form-group">
                                <label for="example-nf-email">Truck Number</label>
                                <input class="form-control" type="text" name="vehicle_no" id="vehicle_no" value="<?= set_value('vehicle_no') ?>">
                               <?php if (isset($validation)) { ?><span class="text-danger"><?= $error = $validation->getError('vehicle_no'); ?></span><?php } ?>
                            </div>
                            <div class="form-group">
                                <label for="example-nf-email">Chassis Number</label>
                                <input class="form-control" type="text" name="chassis_no" id="vehicle_no" value="<?= set_value('chassis_no') ?>">
                               <?php if (isset($validation)) { ?><span class="text-danger"><?= $error = $validation->getError('chassis_no'); ?></span><?php } ?>
                            </div>
                            <div class="form-group">
                                <label for="example-nf-email">Engine Number</label>
                                <input class="form-control" type="text" name="engine_no" id="engine_no" value="<?= set_value('engine_no') ?>">
                               <?php if (isset($validation)) { ?><span class="text-danger"><?= $error = $validation->getError('engine_no'); ?></span><?php } ?>
                            </div>
                            <div class="form-group">
                                    <label for="fitness_exp_date">Fitness Expiry Date</label>
                                    <input class="form-control" type="date" name="fitness_exp_date" id="fitness_exp_date" value="<?= set_value('fitness_exp_date') ?>">
                                    <?php if (isset($validation)) { ?><span class="text-danger"><?= $error = $validation->getError('fitness_exp_date'); ?></span><?php } ?>
                                </div>
                            <div class="form-group">
                                    <label for="fitness_exp_date">Fitness Amount</label>
                                    <input class="form-control" type="text" name="fitness_amount" id="fitness_amount" value="<?= set_value('fitness_amount') ?>">
                                    <?php if (isset($validation)) { ?><span class="text-danger"><?= $error = $validation->getError('fitness_amount'); ?></span><?php } ?>
                                </div>
                                
                            <div class="form-group">
                                    <label for="tax_exp_date">Road Tax Expiry Date</label>
                                    <input class="form-control" type="date" name="tax_exp_date" id="tax_exp_date" value="<?= set_value('tax_exp_date') ?>">
                                    <?php if (isset($validation)) { ?><span class="text-danger"><?= $error = $validation->getError('tax_exp_date'); ?></span><?php } ?>
                                </div>
                                
                            <div class="form-group">
                                    <label for="tax_exp_date">Road Tax Amount</label>
                                    <input class="form-control" type="text" name="road_tax_amount" id="road_tax_amount" value="<?= set_value('road_tax_amount') ?>">
                                    <?php if (isset($validation)) { ?><span class="text-danger"><?= $error = $validation->getError('road_tax_amount'); ?></span><?php } ?>
                                </div>
                                
                            <div class="form-group">
                                <label for="example-nf-email">Insurance Company</label>
                                <input class="form-control" type="text" name="ins_company" id="ins_company" value="<?= set_value('ins_company') ?>">
                                <?php if (isset($validation)) { ?><span class="text-danger"><?= $error = $validation->getError('ins_company'); ?></span><?php } ?>
                            </div>
                            <div class="form-group">
                                <label for="example-nf-email">Insurance Expiry Date</label>
                                <input class="form-control" type="date" name="ins_exp_date" id="ins_exp_date" value="<?= set_value('ins_exp_date') ?>">
                                <?php if (isset($validation)) { ?><span class="text-danger"><?= $error = $validation->getError('ins_exp_date'); ?></span><?php } ?>
                            </div>
                            <div class="form-group">
                                <label for="example-nf-email">Insurance Amount</label>
                                <input class="form-control" type="text" name="Insurance_Amount" id="ins_exp_date" value="<?= set_value('Insurance_Amount') ?>">
                                <?php if (isset($validation)) { ?><span class="text-danger"><?= $error = $validation->getError('ins_exp_date'); ?></span><?php } ?>
                            </div>
                          
                            <div class="form-group">
                                <label for="permit_exp_date"> Permit Expiry Date</label>
                                <input class="form-control" type="date" name="permit_exp_date" id="permit_exp_date" value="<?= set_value('permit_exp_date') ?>">
                                <?php if (isset($validation)) { ?><span class="text-danger"><?= $error = $validation->getError('permit_exp_date'); ?></span><?php } ?>
                            </div>
                            
                            <div class="form-group">
                                <label for="Permit_Amount"> Permit Amount</label>
                                <input class="form-control" type="text" name="Permit_Amount" id="Permit_Amount" value="<?= set_value('Permit_Amount') ?>">
                                <?php if (isset($validation)) { ?><span class="text-danger"><?= $error = $validation->getError('Permit_Amount'); ?></span><?php } ?>
                            </div>
                            
                            
                            <div class="form-group">
                                <label for="permit_exp_date">National Permit Expiry Date</label>
                                <input class="form-control" type="date" name="npermit_exp_date" id="npermit_exp_date" value="<?= set_value('npermit_exp_date') ?>">
                                <?php if (isset($validation)) { ?><span class="text-danger"><?= $error = $validation->getError('npermit_exp_date'); ?></span><?php } ?>
                            </div>
                            
                            <div class="form-group">
                                <label for="Permit_Amount">National Permit Amount</label>
                                <input class="form-control" type="text" name="nPermit_Amount" id="nPermit_Amount" value="<?= set_value('nPermit_Amount') ?>">
                                <?php if (isset($validation)) { ?><span class="text-danger"><?= $error = $validation->getError('nPermit_Amount'); ?></span><?php } ?>
                            </div>
                            
                            
                            <div class="form-group">
                                <label for="example-nf-email">Finance company/ Funding bank  </label>
                                <input class="form-control" type="text" name="finance" id="finance" value="<?= set_value('finance') ?>">
                                <?php if (isset($validation)) { ?><span class="text-danger"><?= $error = $validation->getError('finance'); ?></span><?php } ?>
                            </div>
                            <div class="form-group">
                                <label for="example-nf-email">Deduct Amount</label>
                                <input class="form-control" type="text" name="deduct_Amount" id="deduct_Amount" value="<?= set_value('deduct_Amount') ?>">
                                <?php if (isset($validation)) { ?><span class="text-danger"><?= $error = $validation->getError('deduct_Amount'); ?></span><?php } ?>
                            </div>
                            <div class="form-group">
                                <label for="example-nf-email">Account from EMI deducted</label>
                                <input class="form-control" type="text" name="emi_account" id="emi_account" value="<?= set_value('emi_account') ?>">
                                <?php if (isset($validation)) { ?><span class="text-danger"><?= $error = $validation->getError('emi_account'); ?></span><?php } ?>
                            </div>
                            
                            
                            
                            <div class="form-group">
                                            <label for="example-nf-email">Horse Make</label>
                                            <input class="form-control" type="text" name="horsemake" id="horsemake" value="<?= set_value('horsemake') ?>">
                                            <?php if (isset($validation)) { ?><span class="text-danger"><?= $error = $validation->getError('horsemake'); ?></span><?php } ?>
                                        </div>
                            <div class="form-group">
                                            <label for="example-nf-email">Horse Model</label>
                                            <input class="form-control" type="text" name="HorseModel" id="horsemake" value="<?= set_value('HorseModel') ?>">
                                            <?php if (isset($validation)) { ?><span class="text-danger"><?= $error = $validation->getError('HorseModel'); ?></span><?php } ?>
                                        </div>
                            <div class="form-group">
                                            <label for="example-nf-email">Horse Rate</label>
                                            <input class="form-control" type="text" name="HorseRate" id="HorseRate" value="<?= set_value('HorseRate') ?>">
                                            <?php if (isset($validation)) { ?><span class="text-danger"><?= $error = $validation->getError('HorseRate'); ?></span><?php } ?>
                                        </div>
                            <div class="form-group">
                                            <label for="example-nf-email">Dala Rate</label>
                                            <input class="form-control" type="text" name="DalaRate" id="DalaRate" value="<?= set_value('DalaRate') ?>">
                                            <?php if (isset($validation)) { ?><span class="text-danger"><?= $error = $validation->getError('DalaRate'); ?></span><?php } ?>
                                        </div>
                            <div class="form-group">
                                            <label for="example-nf-email">Dala Make</label>
                                            <input class="form-control" type="text" name="DalaMake" id="DalaMake" value="<?= set_value('DalaMake') ?>">
                                            <?php if (isset($validation)) { ?><span class="text-danger"><?= $error = $validation->getError('DalaMake'); ?></span><?php } ?>
                                        </div>
                            <div class="form-group">
                                            <label for="example-nf-email">RTO Expenses</label>
                                            <input class="form-control" type="text" name="RTOExpenses" id="RTOExpenses" value="<?= set_value('RTOExpenses') ?>">
                                            <?php if (isset($validation)) { ?><span class="text-danger"><?= $error = $validation->getError('RTOExpenses'); ?></span><?php } ?>
                                        </div>
                            <div class="form-group">
                                            <label for="example-nf-email">AMC</label>
                                            <input class="form-control" type="text" name="amc" id="amc" value="<?= set_value('amc') ?>">
                                            <?php if (isset($validation)) { ?><span class="text-danger"><?= $error = $validation->getError('amc'); ?></span><?php } ?>
                                        </div>
                                        
                            <div class="form-group">
                                            <label for="example-nf-email">AMC</label>
                                            <input class="form-control" type="text" name="amc_fre" id="amc" value="<?= set_value('amc_fre') ?>">
                                            <?php if (isset($validation)) { ?><span class="text-danger"><?= $error = $validation->getError('amc_fre'); ?></span><?php } ?>
                                        </div>
                                        
                            <div class="form-group">
                                            <label for="example-nf-email">AMC Monthly Amount</label>
                                            <input class="form-control" type="text" name="amcamount" id="amcamount" value="<?= set_value('amcamount') ?>">
                                            <?php if (isset($validation)) { ?><span class="text-danger"><?= $error = $validation->getError('amcamount'); ?></span><?php } ?>
                                        </div>
                                        
                            <div class="form-group">
                                            <label for="example-nf-email">Amc Expary Date</label>
                                            <input class="form-control" type="date" name="amc_expary" id="Permit" value="<?= set_value('amc_expary') ?>">
                                            <?php if (isset($validation)) { ?><span class="text-danger"><?= $error = $validation->getError('amc_expary'); ?></span><?php } ?>
                                        </div>
                                        
                             <div class="form-group">
                                            <label for="example-nf-email">Amc Frequency</label>
                                            <input class="form-control" type="text" name="amc_frequency" id="Permit" value="<?= set_value('amc_frequency') ?>">
                                            <?php if (isset($validation)) { ?><span class="text-danger"><?= $error = $validation->getError('amc_frequency'); ?></span><?php } ?>
                                        </div>
                                        
                                        
                            <div class="form-group">
                                            <label for="example-nf-email">PUCC</label>
                                            <input class="form-control" type="date" name="Pucc" id="Pucc" value="<?= set_value('Pucc') ?>">
                                            <?php if (isset($validation)) { ?><span class="text-danger"><?= $error = $validation->getError('Pucc'); ?></span><?php } ?>
                                        </div>
                                        
                            <div class="form-group">
                                            <label for="example-nf-email">PUCC Amount </label>
                                            <input class="form-control" type="text" name="Pucc_amount" id="Pucc_amount" value="<?= set_value('Pucc_amount') ?>">
                                            <?php if (isset($validation)) { ?><span class="text-danger"><?= $error = $validation->getError('Pucc_amount'); ?></span><?php } ?>
                                        </div>
                                        
                                        
                             <div class="form-group">
                                            <label for="example-nf-email">I3MS Expairy</label>
                                            <input class="form-control" type="date" name="I3MSexpairy" id="I3MSexpairy" value="<?= set_value('I3MSexpairy') ?>">
                                            <?php if (isset($validation)) { ?><span class="text-danger"><?= $error = $validation->getError('I3MSexpairy'); ?></span><?php } ?>
                                        </div>
                                        
                            <div class="form-group">
                                            <label for="example-nf-email">I3MS RECHARGE</label>
                                            <input class="form-control" type="text" name="I3MSRECHARGE" id="I3MSRECHARGE" value="<?= set_value('I3MSRECHARGE') ?>">
                                            <?php if (isset($validation)) { ?><span class="text-danger"><?= $error = $validation->getError('I3MSRECHARGE'); ?></span><?php } ?>
                                        </div>
                            <div class="form-group">
                                            <label for="example-nf-email">KHANIJEXPIRI</label>
                                            <input class="form-control" type="date" name="KHANIJEXPIRI" id="KHANIJEXPIRI" value="<?= set_value('KHANIJEXPIRI') ?>">
                                            <?php if (isset($validation)) { ?><span class="text-danger"><?= $error = $validation->getError('KHANIJEXPIRI'); ?></span><?php } ?>
                                        </div>
                            <div class="form-group">
                                            <label for="example-nf-email">KHANIJ Amount</label>
                                            <input class="form-control" type="text" name="khanij_amount" id="khanij_amount" value="<?= set_value('khanij_amount') ?>">
                                            <?php if (isset($validation)) { ?><span class="text-danger"><?= $error = $validation->getError('khanij_amount'); ?></span><?php } ?>
                                        </div>
                                        
                            <div class="form-group">
                                <label for="example-nf-email">Remark</label>
                                <input class="form-control" type="text" name="remark" id="remark" value="<?= set_value('remark') ?>">
                               
                            </div>
                            
                            <div>
                                <label for="example-nf-email">Document</label>
                                <input type="file" name="document" class="form-control" />
                            </div>
                            </div>
                       <div class="uk-margin-bottom">
                                            <lable>Location Name</lable>
                                            <select class="form-control"  name="location_name" required >
                                                <option value='' >Select Location</option>
                                                <?php foreach ($location as $loc) {?>
                                                  <option value="<?=$loc->location_id?>"><?=$loc->location_name?></option>
                                                <?php }?>
                                            </select>
                                            
                                           <?php if (isset($validation)) { ?><span class="text-danger"><?= $error = $validation->getError('location_name'); ?></span><?php } ?>
                                        </div> 
                        
                        <div >
                            <lable>&nbsp;</lable>
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                     </div>
                    </form>
</div>
    </div>
</div>
                    
                    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
    function editvehicle(id) {
        $.ajax({
            url: '<?php echo base_url(); ?>/Admin/edit_vehicle', // Replace with your controller method URL
            type: 'POST',
            data: { vehicle_id: id },
            success: function(response) {
                // Assuming 'response' is a JSON object containing vehicle data
                $('#edit_vehicle_form').html(response); // Populate your form with the response data
                
                // Open the UIkit off-canvas
                UIkit.offcanvas('#edit_vehicle').show();
            },
            error: function(xhr, status, error) {
                console.error(error);
            }
        });
    }
</script>

    
    
    

<div id="edit_vehicle" uk-offcanvas="flip: true; overlay: true">
    <div class="uk-offcanvas-bar uk-padding-remove uk-margin-remove uk-width-1-2" style="background:#fff">

        <button class="uk-offcanvas-close" type="button" uk-close></button>
        <div class="uk-card uk-card-body uk-card-small uk-card-default">
            <div id="edit_vehicle_form"></div>
        </div>
    </div>
</div>
    
               
<script>
    $(document).ready(function() {
        // Get today's date
        var today = new Date();

        // Loop through each row in the DataTable
        $('#row_create tbody tr').each(function() {
            // Find the date cell within each row (adjust this selector based on your actual structure)
            var fitnessExpiryCell = $(this).find('td:eq(4)'); // Fitness Expiry Date cell index, adjust as needed
            var taxExpiryCell = $(this).find('td:eq(6)'); // Tax Expiry Date cell index, adjust as needed
            var insExpiryCell = $(this).find('td:eq(9)'); // Insurance Expiry Date cell index, adjust as needed
            var permitExpiryCell = $(this).find('td:eq(11)'); // Permit Expiry Date cell index, adjust as needed
            var nPermitExpiryCell = $(this).find('td:eq(13)'); // National Permit Expiry Date cell index, adjust as needed
            var amcExpiryCell = $(this).find('td:eq(25)'); // AMC Expiry Date cell index, adjust as needed
            var i3msExpiryCell = $(this).find('td:eq(27)'); // I3MS Expiry Date cell index, adjust as needed
            var khanijExpiryCell = $(this).find('td:eq(29)'); // Khanij Expiry Date cell index, adjust as needed

            // Process each date cell to check the condition
            checkAndHighlight(fitnessExpiryCell);
            checkAndHighlight(taxExpiryCell);
            checkAndHighlight(insExpiryCell);
            checkAndHighlight(permitExpiryCell);
            checkAndHighlight(nPermitExpiryCell);
            checkAndHighlight(amcExpiryCell);
            checkAndHighlight(i3msExpiryCell);
            checkAndHighlight(khanijExpiryCell);
        });

        // Function to check date and apply highlight if within 15 days
        function checkAndHighlight(cell) {
            var dateString = cell.text().trim();
            var dateParts = dateString.split('-');
            var expiryDate = new Date(dateParts[2], dateParts[1] - 1, dateParts[0]); // Assuming d-m-Y format

            // Calculate the difference in days
            var diffDays = Math.ceil((expiryDate - today) / (1000 * 60 * 60 * 24));

            // Check if the expiry date is within 15 days from today
            if (diffDays <= 15 && diffDays >= 0) {
                cell.addClass('highlight-red');
            }
        }
    });
</script>

<style>
    .highlight-red {
        background-color: #ffcccc; /* Light red background */
    }
</style>

        <!-- footer start-->
       <?php include("footer.php");?>
