<?php include("header.php"); ?>
<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css'>

<!-- Page Body Start-->
<div class="page-body-wrapper" style="background:#f9f9f9;">
    <?php include("mainsidebar.php"); ?>
    <div class="page-body">
        <div class="container-fluid">
            <div class="page-title">
                <div class="row">
                    <div class="col-sm-6 p-0">
                        <h3>New In House Maintenance</h3>
                    </div>
                    <div class="col-sm-6 p-0"></div>
                </div>
            </div>
        </div>
        <!-- Container-fluid starts-->
        <div class="container-fluid default-dashboard">
            <form name="add_name" id="add_inhouse_maintenance" action="<?php echo base_url();?>/Admin/insert_inhouse" method="post">
                <div class="uk-card uk-card-body uk-card-small" style="border:solid 1px #ccc;">
                    <div class="uk-grid-small uk-child-width-expand@m uk-grid" uk-grid="">
                        <div class="uk-first-column">
                            <label>Select Vehicle</label>
                            <select name="vehicle" id="vehicle" class="form-control">
                                <option value="">Select vehicle</option>
                                <?php foreach ($vehicles as $vec) { ?>
                                    <option value="<?= $vec->id; ?>"><?= $vec->vehicle_no; ?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <div>
                            <div id="vehicle-details">
                                <label>Driver</label>
                                <input type="text" name="driver" class="form-control" readonly />
                            </div>
                        </div>
                        <div>
                            <label>Date</label>
                            <input type="date" id="date" name="date" class="form-control">
                        </div>
                        <div>
                            <label>Time</label>
                            <input type="time" id="time" name="time" class="form-control">
                        </div>
                        <div>
                            <label>Remark</label>
                            <input type="text" name="invoiceno" id="invoiceno" class="form-control" placeholder="remark">
                        </div>
                        <div>
                            <label>Location</label>
                            <select name="location" id="single" class="form-control">
                                <option value="">Select location</option>
                                <?php foreach ($location as $loc) { ?>
                                    <option value="<?= $loc->location_id; ?>"><?= $loc->location_name; ?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <div>
                            <label>Checked by</label>
                            <input type="text" name="check_by" class="form-control" />
                        </div>
                    </div>
                </div>

                <p>&nbsp;</p>

                <div class="uk-grid-small uk-child-width-expand@m uk-grid" uk-grid="">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <table class="table table-bordered table-hover" id="dynamic_field">
                                    <tr>
                                        <td>1</td>
                                        <td>
                                            <select class="form-control type-select">
                                                <option value="1">Service</option>
                                                <option value="2">Product</option>
                                            </select>
                                        </td>
                                        <td>
                                            <select name="items[]" class="form-control items">
                                                <option value="">Select items</option>
                                                <?php foreach ($items as $item) { ?>
                                                    <option value="<?= $item->id; ?>" data-price="<?= $item->amount; ?>"><?= $item->item_name; ?></option>
                                                <?php } ?>
                                            </select>
                                        </td>
                                        <td><div class="availableqty"></div></td>
                                        <td><input type="text" name="qty[]" placeholder="Enter quantity" class="form-control" /></td>
                                        <td><input type="text" name="price[]" placeholder="Enter Price" class="form-control" /></td>
                                        <td><button type="button" name="add" id="add" class="btn btn-primary">Add More</button></td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                
                <button class="btn btn-primary" type="submit">Submit</button>
            </form>
        </div>
        <!-- Container-fluid Ends-->
    </div>
    <!-- Footer start-->
    <?php include("footer.php"); ?>

<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js'></script>
<script src='https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js'></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />

<script>
$(document).ready(function () {
    var i = 1;
    var itemsOptions = <?php echo json_encode(array_map(function($item) {
        return '<option data-price="' . $item->amount . '" value="' . $item->id . '">' . $item->item_name . '</option>';
    }, $items)); ?>;

    function addRow() {
        i++;
        var newRow = $('<tr id="row' + i + '"><td>' + i + '</td><td><select class="form-control type-select"><option value="1">Service</option><option value="2">Product</option></select></td><td><select name="items[]" class="form-control items"><option value="">Select items</option>' + itemsOptions.join('') + '</select></td><td><div class="availableqty"></div></td><td><input type="text" name="qty[]" placeholder="Enter quantity" class="form-control"/></td><td><input type="text" name="price[]" placeholder="Enter Price" class="form-control"/></td><td><button type="button" name="remove" id="' + i + '" class="btn btn-danger btn_remove">X</button></td></tr>');
        $('#dynamic_field').append(newRow);
        applySelect2(newRow);
    }

    $('#add').click(function () {
        addRow();
    });

    $(document).on('click', '.btn_remove', function () {
        var button_id = $(this).attr("id");
        $('#row' + button_id).remove();
    });

    function updatePrice() {
        var selectedItem = $(this).find(":selected");
        var price = selectedItem.data('price');
        var priceInput = $(this).closest('tr').find('input[name="price[]"]');
        priceInput.val(price);
    }

    function updateAvailableQty() {
        var selectedItemId = $(this).val();
        var selectedLocationId = $('#single').val();
        var selectedDate = $('#date').val(); // Correctly fetching the date
        var availableQtyDiv = $(this).closest('tr').find('.availableqty');

        $.ajax({
            url: '<?php echo base_url();?>/Admin/get_stock',
            type: 'POST',
            data: {
                item_id: selectedItemId,
                location_id: selectedLocationId,
                date: selectedDate // Include the date in the request
            },
            success: function(response) {
                availableQtyDiv.html(response);
            },
            error: function(jqXHR, textStatus, errorThrown) {
                availableQtyDiv.html('Error fetching quantity');
            }
        });
    }

    $(document).on('change', 'select[name="items[]"]', function() {
        updatePrice.call(this);
        updateAvailableQty.call(this);
    });

    // Initialize Select2 for existing selects
    applySelect2($(document));

    function applySelect2(element) {
        element.find('.items').select2({
            placeholder: "Select an option",
            allowClear: true
        });
    }
});
</script>
