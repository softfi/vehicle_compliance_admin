<?php include("header.php");?>
      <!-- Page Body Start-->
      <div class="page-body-wrapper" style="background:#f9f9f9;">
        <?php include("mainsidebar.php"); ?>
        <div class="page-body">
          <div class="container-fluid">        
            <div class="page-title">
              <div class="row">
                <div class="col-sm-6 p-0">
                  <h3>Edit Asign Driver </h3>
                </div>
                <div class="col-sm-6 p-0">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">
                        <svg class="stroke-icon">
                          
                        </svg></a></li>
                    <li class="breadcrumb-item">Dashboard</li>
                    <li class="breadcrumb-item active">Asign Driver      </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
          <!-- Container-fluid starts-->
          <div class="container-fluid default-dashboard">
          <?php foreach($drivers_asignment as $das){}?>    
    <div class="uk-card uk-card-body uk-card-default uk-card-small">
        <form id="editForm" action="<?php echo base_url(); ?>/Admin/update_driver_asignment" method="post">
            <input type="hidden" name="id" value="<?=$das->id?>">
            <div class="uk-margin">
                <label for="edit-vehicle_no">Vehicle No:</label>
                <select class="form-control" name="vehicle_no" id="single" required>
                    <option value="">Select Vehicle No.</option>
                    <?php foreach ($vehicles as $vehicle): ?>
                        <option <?php if ($das->vehicle_no==$vehicle->id){echo "selected";}?> value="<?= $vehicle->id; ?>"><?= $vehicle->vehicle_no; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="uk-margin">
                <label for="edit-driver">Driver:</label>
                <select class="form-control" name="driver" id="single1" required>
                    <option value="">Select Driver</option>
                    <?php foreach ($drivers as $driver): ?>
                        <?php if ($driver->user_type == 'DRIVER'): ?>
                            <option <?php if ($das->driver==$driver->id){echo "selected";}?>  value="<?= $driver->id; ?>"><?= $driver->name; ?>(<?= $driver->staff_code; ?>)</option>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="uk-margin">
                <label for="edit-from_date">From Date:</label>
                <input type="date" class="uk-input" name="from_date" id="edit-from_date" value="<?=$das->from_date?>" required>
            </div>
            <div class="uk-margin">
                <label for="edit-opening_hsd">Opening HSD:</label>
                <input type="text" class="uk-input" name="opening_hsd" id="edit-opening_hsd" value="<?=$das->opening_hsd?>" required>
            </div>
            <div class="uk-margin">
                <label for="edit-opening_km">Opening KM:</label>
                <input type="text" class="uk-input" name="opening_km" id="edit-opening_km" value="<?=$das->opening_km?>" required>
            </div>
            <div class="uk-margin">
                <label for="edit-to_date">To Date:</label>
                <input type="date" class="uk-input" name="to_date" id="edit-to_date" value="<?=$das->to_date?>" required>
            </div>
            <div class="uk-margin">
                <label for="edit-closing_hsd">Closing HSD:</label>
                <input type="text" class="uk-input" name="closing_hsd" id="edit-closing_hsd" value="<?=$das->closing_hsd?>" required>
            </div>
            <div class="uk-margin">
                <label for="edit-closing_km">Closing KM:</label>
                <input type="text" class="uk-input" name="closing_km" id="edit-closing_km" value="<?=$das->closing_km?>" required>
            </div>
            <button type="submit" class="uk-button uk-button-primary">Submit</button>
        </form>
    </div>


           
              </div>
           
          </div>
          <!-- Container-fluid Ends-->
        </div>
        <!-- footer start-->
       <?php include("footer.php");?>
