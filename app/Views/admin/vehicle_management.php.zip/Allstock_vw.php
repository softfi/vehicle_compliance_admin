
<?php include("header.php");?>

<?php 
	use App\Models\AdminModel;
	$db = db_connect();
	$this->db = db_connect();
	$this->AdminModel = new AdminModel($db);
?>


      <!-- Page Body Start-->
      <div class="page-body-wrapper">
        <?php include("mainsidebar.php"); ?>
        <div class="page-body">
          <div class="container-fluid">        
            <div class="page-title">
              <div class="row">
                <div class="col-sm-6 p-0">
                     <?php if(in_array(1.1,$jobAssign)){ ?>
                  <a class="btn btn-sm btn-primary uk-align-left" href="<?php echo base_url(); ?>/Admin/Purchaseentry">ENTER STOCKS </a>
                  <?php } ?>
                  <h3>All Purchase Voucher </h3>
                </div>
                <div class="col-sm-6 p-0">
                    
                </div>
              </div>
            </div>
          </div>
          
          
          <!-- Container-fluid starts-->
          <div class="container-fluid default-dashboard">
                	  <div class="table-responsive">
            <table class="display" id="row_create" style="width:100%">
    <thead>
        <tr>
            <th>Sl No</th>
            <th>Date</th>
            <th>Invoice No</th>
            <th>Total Quantity</th>
            <th>Total Amount</th>
            <th>Location</th>
            <th>View</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>
    </thead>
    <tbody>
        <?php 
        $m = 1;
        foreach ($stock_dtls as $stock) { ?>
            <tr>
                <td><?= $m++; ?></td>
                <td><?= date('d-m-Y', strtotime($stock->date)); ?></td>
                <td><?= $stock->invoice_number; ?></td>
                <td><?= $stock->total_quantity; ?></td>
                <td><?= $stock->total_gst_amount; ?></td>
                <td><?= $stock->location_name; ?></td>
                <td>
                    <?php if (in_array(1.2, $jobAssign)) { ?>
                        <a class="btn btn-sm btn-primary" href="#modal-container<?= $stock->stock_code; ?>" uk-toggle>View</a>
                    <?php } ?>
                    
                    <div id="modal-container<?= $stock->stock_code; ?>" class="uk-modal-container" uk-modal>
                        <div class="uk-modal-dialog uk-modal-body">
                            <button class="uk-modal-close-default" type="button" uk-close></button>
                            <div>
                                <table style="width:100%;">
                                    <tbody>
                                        <tr>
                                            <td></td>
                                            <td>&nbsp;</td>
                                            <td style="text-align:right;">
                                                Invoice No: <?= $stock->invoice_number; ?><br>
                                                Order Date: <?= date('d-m-Y', strtotime($stock->date)); ?>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <p>&nbsp;</p>
                                <table width="100%" border="0" cellpadding="5" cellspacing="0" style="border:solid 1px #ccc;" class="uk-table uk-table-small">
                                    <tbody>
                                        <tr>
                                            <td style="width:50px; border: solid 1px #ccc;">Sl No</td>
                                            <td style="width:350px; border: solid 1px #ccc;">Product Name</td>
                                            <td style="width:150px; border: solid 1px #ccc;">Quantity</td>
                                            <td style="width:150px; border: solid 1px #ccc;">Rate</td>
                                            <td style="width:150px; border: solid 1px #ccc;">Amount</td>
                                        </tr>
                                        <?php 
                                        $single_stock_dtls = $this->AdminModel->singleStock($stock->stock_code);
                                        $i = 1;
                                        foreach ($single_stock_dtls as $stk_dtls) { ?>
                                            <tr>
                                                <td style="width:50px; border: solid 1px #ccc;"><?= $i++; ?></td>
                                                <td style="width:350px; border: solid 1px #ccc;"><?= $stk_dtls->item_name; ?></td>
                                                <td style="width:150px; border: solid 1px #ccc;"><?= $stk_dtls->quantity . ' ' . $stk_dtls->unit_name; ?></td>
                                                <td style="width:150px; border: solid 1px #ccc;"><?= $stk_dtls->rate; ?></td>
                                                <td style="width:100px; border: solid 1px #ccc;"><?= $stk_dtls->quantity * $stk_dtls->rate; ?></td>
                                            </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                                <hr>
                            </div>
                        </div>
                    </div>
                </td>
                <td><a href="<?= base_url(); ?>/admin/edit_stock/<?= $stock->stock_code; ?>" class="btn btn-sm btn-success">Edit</a></td>
                <td>
                    <?php if (in_array(1.3, $jobAssign)) { ?>
                        <a href="javascript:void(0);" onClick="deleteRecord('<?= $stock->stock_code; ?>');" class="btn btn-sm btn-danger">Delete</a>
                    <?php } ?>
                </td>
            </tr>
        <?php } ?>
    </tbody>
</table>
            </div> 
          </div>
          <!-- Container-fluid Ends-->
        </div>
        <!-- footer start-->
        
<form name="frm_deleteBanner" id="frm_deleteBanner" action="<?php echo base_url(); ?>/admin/delete_stock" method="post">
    <input type="hidden" name="user_id" id="user_id" value="">
</form>

<script type="text/javascript">
    function deleteRecord(id) {
        $("#operation").val('delete');
        $("#user_id").val(id);
        var conf = confirm("Are you sure want to delete this Product");
        if (conf) {
            $("#frm_deleteBanner").submit();
        }
    }
</script>



 <form name="frm_deleteBanner" id="frm_deleteBanner" action="<?php echo base_url(); ?>/admin/deleteordercart" method="post">
        <input type="hidden" name="user_id" id="user_id" value="">
    </form>

    <script type="text/javascript">
        function deleteRecord(id) {
            $("#operation").val('delete');
            $("#user_id").val(id);
            var conf = confirm("Are you sure want to delete this record");
            if (conf) {
                $("#frm_deleteBanner").submit();
            }
        }
    </script>

       <?php include("footer.php");?>






















































