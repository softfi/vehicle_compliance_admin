<?php include("header.php");?>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />


      <!-- Page Body Start-->
      <div class="page-body-wrapper">
        <?php include("mainsidebar.php"); ?>
        <div class="page-body">
          <div class="container-fluid">        
            <div class="page-title">
              <div class="row">
                <div class="col-sm-6 p-0">
                  <h3>Stock</h3>
                </div>
                <div class="col-sm-6 p-0">
                  
                </div>
              </div>
            </div>
          </div>
          <!-- Container-fluid starts-->
          <div class="container-fluid default-dashboard">
            
    <!-- Example Block -->
    <div class="block">
        <!-- Example Title -->
        <div class="block-title">
            <h2><strong>Enter Stocks Data</strong></h2>
        </div>
        <?php foreach ($cart_dtls as $cartm) {
        } ?>
        <?php foreach ($stock_edit as $stock){} ?>
        
                <div class="uk-card uk-card-body uk-card-small" style="border:solid 1px #ccc;">
                    <div class="uk-grid-small uk-child-width-expand@m" uk-grid>
                        <div>
                            <lable>Select Supplier</lable>
                            <select class="form-control" name="supplier_id" id="supplierSelect">
                                <option value="">Select Supplier</option>
                                
                                <?php foreach ($vendor as $supp) { 
                                if($supp->type!="Pump"){?>
                                    <option <?php if (!empty($cartm)) {
                                                if ($cartm->supplier_id == $supp->id) {
                                                    echo "selected";
                                                }
                                            } ?> value="<?= $supp->id; ?>"><?= $supp->name; ?></option>
                                <?php }} ?>
                            </select>
                        </div>
                        <div>
                            <lable>Location</lable>
                            <select name="location" id="location" class="form-control">
                                <option value="">Select Location</option>
                                <?php foreach($location as $loc){?>
                                    <option 
                                    <?php if (!empty($cartm)) {
                                                if ($cartm->location == $loc->location_id) {
                                                    echo "selected";
                                                }
                                            } ?>
                                            value="<?=$loc->location_id?>"><?=$loc->location_name?></option>

                                <?php }?>
                            </select>
                        </div>
                        <div>
                            <lable>Date</lable>
                            <input type="date" name="invoicedate" 
       value="<?php if (!empty($stock)) { 
                        echo date('Y-m-d', strtotime($stock->date)); 
                    } else { 
                        echo date('Y-m-d'); 
                    } ?>" 
       class="form-control" />

                        </div>
                        <div>
                            <lable>Invoice No</lable>
                            <input type="text" name="invoiceno" id="invoiceno" class="form-control" value="<?php if (!empty($cartm)) {
                                                                                echo $cartm->invoiceno;
                                                                            } ?>" />
                        </div>
                        <div>
                            <label>Select Items</label><br>
                            <select class="form-control select2 product" name="product" id="product" >
    <option value="">Select Model No</option>
    <?php foreach ($product as $productt) { ?>
        <option value="<?= $productt->id; ?>" data-details="<?= htmlspecialchars(json_encode($productt)); ?>">  <?= $productt->item_name; ?> </option>
    <?php } ?>
</select>

                        </div>
                        <div class="uk-width-auto">
                            <p></p>
                            <button class="btn btn-primary" id="addButton">Add</button></div>
                      
                        </div>
                    </div>
               
            <p></p>
        </div>

        <div class="table table-responsive uk-margin-top" id="responseContainer">

            <table class="table table-responsive table-striped table-bordered" style="border:solid 1px #ccc;">
                <thead>
                    <tr>
                        <th class="text-center">SI.No.</th>
                        <th class="text-center">Product Name No</th>
                        <th class="text-center">Quentity</th>
                        <th class="text-center">Rate</th>
                        <th class="text-center"> Amount</th>                        
                        <td>Action</td>
                    </tr>
                </thead>
                <tbody>
                
                                                      
												
													
														     
                                                         <?php 
														 $i=1;
                                                         $total_amount = 0;
                                                      
														 foreach($stock_edit as $stk_dtls){
                                                            $total_amount += $stk_dtls->quantity*$stk_dtls->rate;

                                                            ?>
                                                             <tr>
                                                               <td><?=$i++;?></td>
                                                               <td><?=$stk_dtls->item_name?></td>
                                                              
                                                               <td> <?=$stk_dtls->quantity?> <?=$stk_dtls->unit_name?> </td>
                                                                <td><?=$stk_dtls->rate?></td>
                                                               <td><?=$stk_dtls->quantity*$stk_dtls->rate ?>  </td>
                                                              <td><a href="" class="btn btn-sm btn-success">Edit</a></td>
                                                            </tr>
                                                             <?php } ?>                                                     
                                                         
                                                      </tbody>
                                                      <tfoot>
                                    <tr>
                                        <th colspan="4">Total Amount</th>
                                        <th><?= $total_amount; ?></th>
                                    </tr>
                                </tfoot>
            </table>



        </div>

        <p></p>
                
                
          </div>
          <!-- Container-fluid Ends-->
        </div>
        
        <form name="frm_deleteBanner" id="frm_deleteBanner" action="<?php echo base_url(); ?>/admin/deletepurchasecart" method="post">
        <input type="hidden" name="user_id" id="user_id" value="">
    </form>

    <script type="text/javascript">
        function deleteRecord(id) {
            $("#operation").val('delete');
            $("#user_id").val(id);
            var conf = confirm("Are you sure want to delete this record");
            if (conf) {
                $("#frm_deleteBanner").submit();
            }
        }
    </script>
        
        <script>
        $("#supplierSelect").select2({
        placeholder: "Select an option",
        allowClear: true
    });
    
     $("#product").select2({
        placeholder: "Select an option",
        allowClear: true
    });
    
        $(document).ready(function() {
            $('#addButton').on('click', function() {
                // Collect selected values
    
                var supplierId = $('#supplierSelect').val();
                var invoicedate = $('input[name="invoicedate"]').val();
                var productId = $('#product').val();
                var invoiceno = $('#invoiceno').val();
                var location = $('#location').val();
                

                 

                // Validate the fields
                if (supplierId === '' || invoicedate === ''  || productId === '') {
                    alert('Please enter all required fields.');
                    return; // Stop execution if validation fails
                }

                // Send values to AJAX endpoint
                $.ajax({
                    type: 'POST',
                    url: '<?php echo base_url(); ?>/Admin/frm_addtocartpurchase',
                    data: {
                        supplierId: supplierId,
                        invoicedate: invoicedate,
                        productId: productId,
                        invoiceno: invoiceno,
                        location_id: location,
                    },
                    success: function(response) {
                        // Handle the response and update your HTML
                        // For example, you can update a div with the response
                        $('#responseContainer').html(response);
                    },
                    error: function(error) {
                        console.error('AJAX Error:', error);
                    }
                });
            });
        });
    </script>
    
    
    <script>
        $(document).ready(function() {
            // Listen for changes in any input field with the class 'cart-data'
            $('#TextBoxContainer').on('change', 'input.cart-data', function() {
                // Get the closest row to the changed input field
                var currentRow = $(this).closest('tr');

                // Gather all input values within the current row
                var formData = {
                    cart_id: currentRow.find('.cart-data[name="cart_id"]').val(),
                    qty: currentRow.find('.cart-data[name="qty"]').val(),
                    rate: currentRow.find('.cart-data[name="rate"]').val(),
                   
                };
              
                // Send the data to the server using AJAX
                $.ajax({
                    type: 'POST',
                    url: '<?php echo base_url(); ?>/Admin/frm_updatepurchasecart',
                    data: formData,
                    success: function(response) {
                        // Update the HTML with the response
                        $('#responseContainer').html(response);
                    },
                    error: function(xhr, status, error) {
                        console.error('AJAX Error:', status, error);
                    }
                });
            });
        });
    </script>
    
    
    
        <!-- footer start-->
       <?php include("footer.php");?>

