<?php include("header.php");?>
      <!-- Page Body Start-->
      <div class="page-body-wrapper">
        <?php include("mainsidebar.php"); ?>
        <div class="page-body" style="background:#f1f1f1;">
          <div class="container-fluid">        
            <div class="page-title">
              <div class="row">
                <div class="col-sm-6 p-0">
                  <h3>Stock Report </h3>
                </div>
                <div class="col-sm-6 p-0">
                  
                </div>
              </div>
            </div>
          </div>
          <!-- Container-fluid starts-->
          <div class="container-fluid default-dashboard">
            <div class="row">
              <div class="col-sm-12 left-background">
               
               
             <div id="page-content">
                 <form action="<?php echo base_url(); ?>/Admin/Stock_Report" method="post" class="uk-card uk-card-body uk-card-default uk-card-small uk-margin-bottom">
                    <div class="uk-grid-small" uk-grid>
                        <div class="uk-width-1-3@s">
                            <label for="from_date">From Date</label>
                            <input class="uk-input" value="<?=$date['from_date'];?>" type="date" id="from_date" name="from_date" required>
                        </div>
                        <div class="uk-width-1-3@s">
                            <label for="to_date">To Date</label>
                            <input class="uk-input" type="date" id="to_date" value="<?=$date['to_date'];?>" name="to_date" required>
                        </div>
                        <div class="uk-width-1-3@s">
                            <label for="location">Location</label>
                            <select class="uk-select" id="location" name="location" required>
                                <option value="">Select Location</option>
                                <?php foreach ($locations as $location) { ?>
                                    <option value="<?= $location->location_id ?>" <?php if ($location->location_id==$date['location']){echo "selected";} ?>><?= $location->location_name ?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                    <div class="uk-margin-top">
                        <button class="uk-button uk-button-primary" type="submit">Submit</button>
                        <button class="btn btn-primary" type="button" onclick="downloadExcel()">Download Excel</button>

                    </div>
                </form>
  
            <div class="uk-card uk-card-body uk-card-default uk-card-small">
                
                <div class="table-responsive custom-scrollbar custom-scrollbar">
                     <table class="display" id="row_create" style="width:100%">
                         
                        <thead>
                            <tr>
                                <th>Sl.#</th>
                                <th>Item Name</th>
                                <th>Unit</th>
                                <th>Amount</th>
                                <th>Opening Stocks</th>
                                <th>Consume</th>
                                <th>available Stock</th>
                                <th></th>
                                
                               
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $i = 1;
                            foreach ($stock_dtls as $stock) {
                               
                            ?>
                                <tr>
                                    <td><?= $i++; ?></td>
                                    <td><?= $stock->item_name; ?></td>
                                    <td><?= $stock->unit_short_name; ?></td>
                                    <td><?= number_format($stock->amount, 2); ?></td>
                                    <td><?= $stock->opening_stock; ?></td>
                                    <td><?=$stock->stock_out_store?></td>
                                     <td><?= $stock->opening_stock+$stock->stock_in_store-$stock->stock_out_store; ?></td>
                                    <td></td>
                                    
                                </tr>
                            <?php } ?>
                        </tbody>
                        
                         <tfoot>
                            <tr>
                                <th>Sl.#</th>
                                <th>Item Name</th>
                                <th>Unit</th>
                                <th>Amount</th>
                                <th>Opening Stocks</th>
                                <th>Consume</th>
                                <th>available Stock</th>
                                <th></th>
                               
                            </tr>
                        </tfoot>
                        
                    </table>
                </div>
            </div>
        
</div>


              </div>
              
            </div>
          </div>
          <!-- Container-fluid Ends-->
        </div>
        <script>
    function downloadExcel() {
        // Get the selected values from the inputs
        var from_date = document.getElementById('from_date').value;
        var to_date = document.getElementById('to_date').value;
        var location = document.getElementById('location').value;

        // Create a form element
        var form = document.createElement('form');
        form.method = 'POST';
        form.action = '<?= base_url(); ?>/Admin/export_stock_report_to_excel'; // Adjust the action to point to the Excel export route

        // Create input elements for form data
        var inputFromDate = document.createElement('input');
        inputFromDate.type = 'hidden';
        inputFromDate.name = 'from_date';
        inputFromDate.value = from_date;

        var inputToDate = document.createElement('input');
        inputToDate.type = 'hidden';
        inputToDate.name = 'to_date';
        inputToDate.value = to_date;

        var inputLocation = document.createElement('input');
        inputLocation.type = 'hidden';
        inputLocation.name = 'location';
        inputLocation.value = location;

        // Append inputs to the form
        form.appendChild(inputFromDate);
        form.appendChild(inputToDate);
        form.appendChild(inputLocation);

        // Append form to the body
        document.body.appendChild(form);

        // Submit the form
        form.submit();

        // Remove the form from the document
        document.body.removeChild(form);
    }
</script>

        <!-- footer start-->
       <?php include("footer.php");?>