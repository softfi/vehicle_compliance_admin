<?php include("header.php"); ?>
<!-- Page Body Start-->
<div class="page-body-wrapper" style="background:#ececec;">
    <?php include("mainsidebar.php"); ?>
    <div class="page-body">
        <div class="container-fluid">
            <div class="page-title">
                <div class="row">
                    <div class="col-sm-6 p-0">
                        <h3>Do Registration</h3>
                    </div>
                    <div class="col-sm-6 p-0">
                    </div>
                </div>
            </div>
        </div>
        <!-- Container-fluid starts-->
        <div class="container-fluid default-dashboard">
            <div class="uk-grid-small" uk-grid>
                <div class="uk-width-1-3@m">
                    <div class="uk-card uk-card-body uk-card-default uk-card-small">
                        <form action="<?php echo base_url(); ?>/Admin/insert_do_registration" enctype="multipart/form-data" method="post">
                            <div class="uk-margin-bottom">
                                <label>DO No </label>
                                <input type="text" name="do_no" placeholder="enter DO No" id="do_no" class="uk-input" value="<?= set_value('do_no') ?>" />
                                <?php if (isset($validation)) { ?><span class="text-danger"><?= $validation->getError('do_no'); ?></span><?php } ?>
                            </div>
                            <div class="">
                                <label>Route </label>
                                <select class="js-states form-control uk-padding-reove uk-margin-remove" name="route" id="single">
                                    <option value="">Select Route</option>
                                    <?php foreach ($route as $rut) { ?>
                                    <option value="<?= $rut->id ?>">(<?= $rut->location_shortname ?>) <?= $rut->from_city ?> === <?= $rut->to_city ?></option>
                                    <?php } ?>
                                </select>
                                <?php if (isset($validation)) { ?><span class="text-danger"><?= $validation->getError('route'); ?></span><?php } ?>
                            </div>
                            <div class="uk-margin-bottom">
                                <label>Diesel/Trip OR Km</label>
                               <input type="number" name="diesel" class="form-control" value="<?= set_value('diesel') ?>" />
                                <?php if (isset($validation)) { ?><span class="text-danger"><?= $validation->getError('diesel'); ?></span><?php } ?>
                            </div>
                            
                            
                            
                        <div class="uk-child-width-1-2@m uk-grid-small " uk-grid>
                            
                        
                           
                            <div class="uk-margin-bottom">
                                <label>1=Trip Expenses</label>
                                <input type="text"  placeholder="enter 1Trip Expenses" id="trip_expenses" class="uk-input" name="1trip_expenses" value="<?= set_value('1trip_expenses') ?>" />
                                <?php if (isset($validation)) { ?><span class="text-danger"><?= $validation->getError('1trip_expenses'); ?></span><?php } ?>
                            </div>
                            
                             <div class="uk-margin-bottom">
                                <label>2=Trip Expenses</label>
                                <input type="text"  placeholder="enter 2 Trip Expenses" id="trip_expenses" class="uk-input" name="2trip_expenses" value="<?= set_value('2trip_expenses') ?>" />
                                <?php if (isset($validation)) { ?><span class="text-danger"><?= $validation->getError('2trip_expenses'); ?></span><?php } ?>
                            </div>
                            
                            <div class="uk-margin-bottom">
                                <label>3=Trip Expenses</label>
                                <input type="text"  placeholder="enter 3 Trip Expenses" id="trip_expenses" class="uk-input" name="3trip_expenses" value="<?= set_value('3trip_expenses') ?>" />
                                <?php if (isset($validation)) { ?><span class="text-danger"><?= $validation->getError('3trip_expenses'); ?></span><?php } ?>
                            </div>
                            
                            <div class="uk-margin-bottom">
                                <label>4=Trip Expenses</label>
                                <input type="text"  placeholder="enter 4Trip Expenses" id="trip_expenses" class="uk-input" name="4trip_expenses" value="<?= set_value('4trip_expenses') ?>" />
                                <?php if (isset($validation)) { ?><span class="text-danger"><?= $validation->getError('4trip_expenses'); ?></span><?php } ?>
                            </div>
                            
                             <div class="uk-margin-bottom">
                                <label>5=Trip Expenses</label>
                                <input type="text"  placeholder="enter 5 Trip Expenses" id="trip_expenses" class="uk-input" name="5trip_expenses" value="<?= set_value('5trip_expenses') ?>" />
                                <?php if (isset($validation)) { ?><span class="text-danger"><?= $validation->getError('5trip_expenses'); ?></span><?php } ?>
                            </div>
                            
                            <div class="uk-margin-bottom">
                                <label>6=Trip Expenses</label>
                                <input type="text"  placeholder="enter 6 Trip Expenses" id="trip_expenses" class="uk-input" name="6trip_expenses" value="<?= set_value('6trip_expenses') ?>" />
                                <?php if (isset($validation)) { ?><span class="text-danger"><?= $validation->getError('6trip_expenses'); ?></span><?php } ?>
                            </div>
                            
                            
                            
                            <!-- <div class="uk-margin-bottom">-->
                            <!--    <label>Bonus after trip</label>-->
                            <!--   <input type="number" name="max_trip" class="form-control" value="<?= set_value('max_trip') ?>" />-->
                            <!--    <?php if (isset($validation)) { ?><span class="text-danger"><?= $validation->getError('max_trip'); ?></span><?php } ?>-->
                            <!--</div>-->
                            <!--<div class="uk-margin-bottom">-->
                            <!--    <label>Bonus/Trip </label>-->
                            <!--    <input type="text" name="bonus" placeholder="enter Bonus/Trip" id="bonus" class="uk-input" value="<?= set_value('bonus') ?>" min="0" />-->
                            <!--    <?php if (isset($validation)) { ?><span class="text-danger"><?= $validation->getError('bonus'); ?></span><?php } ?>-->
                            <!--</div>-->
                            
                           
                            <div class="uk-margin-bottom">
                                <label>From Date </label>
                                <input type="date" name="from_date" placeholder="Upload from date" id="from_date" class="uk-input" value="<?= set_value('from_date') ?>" />
                                <?php if (isset($validation)) { ?><span class="text-danger"><?= $validation->getError('from_date'); ?></span><?php } ?>
                            </div>
                            <div class="uk-margin-bottom">
                                <label>To date </label>
                                <input type="date" name="to_date" placeholder="Upload from date" id="to_date" class="uk-input" value="<?= set_value('to_date') ?>" />
                                <?php if (isset($validation)) { ?><span class="text-danger"><?= $validation->getError('to_date'); ?></span><?php } ?>
                            </div>
                             <div class="uk-margin-bottom">
                                <label>Party</label>
                                <input type="text" name="party" placeholder="enter Party" id="party" class="uk-input" value="<?= set_value('party') ?>" />
                                <?php if (isset($validation)) { ?><span class="text-danger"><?= $validation->getError('party'); ?></span><?php } ?>
                            </div>
                            
                            <div class="uk-margin-bottom">
                                <label>Rate </label>
                                <input type="number" name="rate" placeholder="Enter Rate" id="rate" class="uk-input" value="<?= set_value('rate') ?>" />
                                <?php if (isset($validation)) { ?><span class="text-danger"><?= $validation->getError('rate'); ?></span><?php } ?>
                            </div>
                            
                            </div>
                            
                            <div class="uk-margin-bottom">
                                 <?php if(in_array(2.1,$jobAssign)){ ?>
                                <button type="submit" class="btn btn-primary">Submit</button>
                                <?php } ?>
                            </div>
                        </form>
                        <!--<hr>-->
                        <!--<form action="<?php echo base_url(); ?>/Admin/excel_location" method="post" enctype="multipart/form-data">-->
                        <!--    <div class="uk-margin-bottom">-->
                        <!--        <input type="file" name="file" id="file" class="form-control" accept=".csv, .xlsx">-->
                        <!--    </div>-->
                        <!--    <div class="uk-margin-bottom">-->
                        <!--        <button type="submit" class="btn btn-primary">Upload Excel</button>-->
                        <!--    </div>-->
                        <!--</form>-->
                    </div>
                </div>
                <div class="uk-width-expand@m">
                    <div class="uk-card uk-card-body uk-card-default uk-card-small">
                        <div class="table-responsive">
                            <table id="example" class="table table-vcenter table-condensed table-bordered">
                                <thead>
                                    <tr>
                                        <th>Sl no</th>
                                        <th>DO No</th>
                                        <th>Route</th>
                                        <th>Diesel/Trip OR Km</th>
                                        <th>Trip Expenses</th>
                                        
                                        <th>Party</th>
                                        <th>From Date</th>
                                        <th>To Date</th>
                                        <th>Rate</th>
                                        <th>Change</th>
                                        <th>Edit</th>
                                        <th>Delete</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $i=1;
                                    foreach ($doregistration as $doreg){ ?>
                                    <tr>
                                        <td><?=$i++;?></td>
                                        <td><?=$doreg->do_no;?></td>
                                        <td><?=$doreg->location_shortname;?></td>
                                        <td><?=$doreg->diesel_type;?></td>
                                        <td> 1<sup>st</sup>=Rs. <?=$doreg->trip_expenses1;?>, 2<sup>nd</sup>=Rs.<?=$doreg->trip_expenses2;?>, <br> 
                                             3<sup>rd</sup>=Rs. <?=$doreg->trip_expenses3;?>, 4<sup>th</sup>=Rs.<?=$doreg->trip_expenses4;?>,<br>  
                                             5<sup>th</sup>=Rs. <?=$doreg->trip_expenses5;?>, 6<sup>th</sup>=Rs. <?=$doreg->trip_expenses6;?>,</td>
                                        <td><?=$doreg->party;?></td>
                                        <td><?=$doreg->from_date;?></td>
                                        <td><?=$doreg->to_date;?></td>
                                        <td><?=$doreg->rate;?></td>
                                        <td>
                                           <?php if(in_array(2.2,$jobAssign)){ ?>
                                            <a class="btn btn-success" href="javascript:void(0);" onClick="changedoprice('<?=$doreg->do_registration_id;?>');">Change Price</a>
                                            <?php } ?>
                                            </td>
                                        <td>
                                            <?php if(in_array(2.3,$jobAssign)){ ?>
                                            <a class="btn btn-warning" href="javascript:void(0);" onClick="editdoregistration('<?=$doreg->do_registration_id;?>');">Edit</a>
                                            <?php }?>

                                            </td>
                                        <td>
                                            <?php if(in_array(2.4,$jobAssign)){ ?>
                                            <a href="javascript:void(0);" onClick="deleteRecord('<?=$doreg->do_registration_id;?>');" class="btn btn-danger">Delete</a>
                                            <?php }?>
                                            </td>
                                    </tr>
                                    <?php } ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>Sl no</th>
                                        <th>DO No</th>
                                        <th>Route</th>
                                        <th>Diesel/Trip OR Km</th>
                                        <th>Trip Expenses</th>
                                       
                                        <th>Party</th>
                                        <th>From Date</th>
                                        <th>To Date</th>
                                        <th>Rate</th>
                                        <th>Change</th>
                                        <th>Edit</th>
                                        <th>Delete</th>
                                        <th></th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Container-fluid Ends-->
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
    function editdoregistration(id) {
        $.ajax({
            url: '<?php echo base_url(); ?>/Admin/edit_doregistration', // Replace with your controller method URL
            type: 'POST',
            data: { doreg_id: id },
            success: function(response) {
                // Assuming 'response' is a JSON object containing vehicle data
                $('#edit_do_form').html(response); // Populate your form with the response data
                
                // Open the UIkit off-canvas
                UIkit.offcanvas('#edit_doreg').show();
            },
            error: function(xhr, status, error) {
                console.error(error);
            }
        });
    }
</script>



<script>
    function changedoprice(id) {
        $.ajax({
            url: '<?php echo base_url(); ?>/Admin/changeprice_doregistration', // Replace with your controller method URL
            type: 'POST',
            data: { doreg_id: id },
            success: function(response) {
                // Assuming 'response' is a JSON object containing vehicle data
                $('#edit_do_form').html(response); // Populate your form with the response data
                
                // Open the UIkit off-canvas
                UIkit.offcanvas('#edit_doreg').show();
            },
            error: function(xhr, status, error) {
                console.error(error);
            }
        });
    }
</script>


    
    

<div id="edit_doreg" uk-offcanvas="flip: true; overlay: true">
    <div class="uk-offcanvas-bar uk-padding-remove uk-margin-remove uk-width-1-3@m" style="background:#fff">

        <button class="uk-offcanvas-close" type="button" uk-close></button>
        <div class="uk-card uk-card-body uk-card-small uk-card-default">
            <div id="edit_do_form"></div>
        </div>
    </div>
</div>



<form name="frm_deleteBanner" id="frm_deleteBanner" action="<?php echo base_url();?>/admin/delete_doregistration" method="post">
     <input type="hidden" name="user_id" id="user_id" value="">
     </form>
    <script type="text/javascript">
    function deleteRecord(id){
    	$("#user_id").val(id);
    	var conf=confirm("Are you sure want to delete this record");
    	if(conf){
    	   $("#frm_deleteBanner").submit();
    	}
    }
    </script> 
<!-- footer start-->


<?php include("footer.php"); ?>
