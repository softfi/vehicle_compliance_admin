<?php include("header.php");?>
      <!-- Page Body Start-->
      <div class="page-body-wrapper" style="background:#ececec;">
        <?php include("mainsidebar.php"); ?>
        <div class="page-body">
          <div class="container-fluid">        
            <div class="page-title">
              <div class="row">
                <div class="col-sm-6 p-0">
                  <h3>Statutory Entry  </h3>
                </div>
                <div class="col-sm-6 p-0">
                </div>
              </div>
            </div>
          </div>
          <!-- Container-fluid starts-->
          <div class="container-fluid default-dashboard">
           <div class="uk-grid-small" uk-grid>
                <div class="uk-width-1-1@m">
                     <div class="uk-card uk-card-body uk-card-default uk-card-small ">
                  <form action="<?php echo base_url(); ?>/Admin/insert_Statutory" method="post">
                      <div class="uk-grid-small uk-child-width-expand" uk-grid>
                       
                                         <div>
                                            <label>Vehicle No.</label>
                                                <select class="form-control" id="single" name="vehicle_no">
                                                    <option value="trip">select</option>
                                                    <?php foreach($vehicle as $vec){?>
                                                    <option value="<?=$vec->id;?>"><?=$vec->vehicle_no;?></option>
                                                    <?php } ?>
                                                </select>
                                        </div> 
                                  <div>
                                    <label>Type</label>
                                        <select class="form-control" name="type">
                                            <option value="road_tax">Road Tax</option>
                                            <option value="insurance">Insurance</option>
                                            <option value="Fitness">Fitness</option>
                                            <option value="permit">Permit</option>
                                            <option value="national_permit">National Permit</option>
                                            <option value="pucc">PUCC</option>
                                            <option value="AMC">AMC</option>
                                            <option value="rto_penalty">RTO Pennlty</option>
                                            <option value="Servicing">Servicing</option>
                                            <option value="I3MS">I3MS RECHARGE</option>
                                            <option value="KHANIJ">KHANIJ EXPIRI</option>
                                        </select>
                                </div> 
                                
                                         <div class="uk-margin-bottom">
                                            <label>Amount</label>
                                            <input type="number" name="Amount" placeholder="Amount" id="Amount" class="uk-input" value="" />
                                        </div>
                                         <div class="uk-margin-bottom">
                                            <label>Expary Date</label>
                                            <input type="date" name="exp_date" placeholder="Expary Date" id="exp_date" class="uk-input" value="" />
                                        </div>
                                         <div class="uk-margin-bottom">
                                            <label>Done By</label>
                                            <input type="text" name="done_by" placeholder="Done  By" id="done_by" class="uk-input" value="" />
                                        </div>
                                        
                                        <div class="uk-margin-bottom">
                                           <label class="uk-padding-small"></label>
                                <?php if(in_array(14.1,$jobAssign)){ ?>
                                <button type="submit" class="btn btn-primary">Submit</button>
                                <?php }?>
                            </div>
                                        </div>
                                         
                                </form>
                        </div>
                </div>
                    <div class="uk-width-1-1@m">
                        <div class="uk-card uk-card-body uk-card-default uk-card-small ">
                             <div class="table-responsive custom-scrollbar custom-scrollbar">
                            <table class="display" id="row_create" style="width:100%">
                                       <thead>
                                           <tr>
                                               <th>Sl no</th>
                                               <th>Vehicle no</th>
                                               <th>Expence type</th>
                                               <th>Amount</th>
                                               <th>Date</th>
                                               <th>Done by</th>
                                               <th>Action</th>
                                               
                                           </tr>
                                       </thead>
                            <tbody>
                                <?php 
                                $i=1;
                                foreach($satutary as $sat){?>
                                <tr>
                                    <td><?=$i++; ?></td>
                                    <td><?=$sat->vehicle_no?></td>
                                    
                                    <td><?=$sat->expence_type;?></td>
                                    
                                    <td><?=$sat->amount?></td>
                                    <td><?=$sat->expary_date?></td>
                                    <td><?=$sat->done_by?></td>
                                    <td>
                                                    <?php if(in_array(14.2,$jobAssign)){ ?>
                                        <a href="<?= base_url('Admin/deletesat/'.$sat->statutory_id); ?>" onclick="return confirm('Are you sure you want to delete this record?');" class="uk-button uk-button-small uk-button-danger">delete</a>
                                    <?php }?>
                                    </td>
                                </tr>
                                <?php } ?>
                               
                                </tbody>
                                <tfoot>
                                    
                                     <tr>
                                          <th>Sl no</th>
                                               <th>Vehicle no</th>
                                               <th>Expence type</th>
                                               <th>Amount</th>
                                               <th>Date</th>
                                               <th>Done by</th>
                                               <th>Action</th>
                                           </tr>
                                </tfoot>
                             </table>  
                            </div>
                        </div> 
                    </div>
                  </div>
                  <!-- Container-fluid Ends-->
                </div>
        <!-- footer start-->
         </div>
        </div>
        
 
       <?php include("footer.php");?>
