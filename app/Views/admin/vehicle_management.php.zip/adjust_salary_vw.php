<?php include("header.php"); ?>
<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css'>

<!-- Page Body Start-->
<div class="page-body-wrapper" style="background:#f9f9f9;">
    <?php include("mainsidebar.php"); ?>
    <div class="page-body">
        <div class="container-fluid">
            <div class="page-title">
                <div class="row">
                    <div class="col-sm-6 p-0">
                        <h3>Adjust Salary</h3>
                    </div>
                    <div class="col-sm-6 p-0"></div>
                </div>
            </div>
        </div>
<div class="container-fluid default-dashboard">        
<div class="uk-grid-small" uk-grid>
            <div class="uk-width-1-1@m">
                <div class="uk-card uk-card-body uk-card-default uk-card-small">
                    <form id="driverForm" action="<?php echo base_url(); ?>/admin/add_adjust_salary" method="POST">
                        <div class="uk-grid-small uk-child-width-expand" uk-grid>
                            
                            <!-- Driver Name -->
                           <div class="form-group">
            <label for="driver">Driver:</label>
            <select class="form-control" name="driver" id="single" required>
                <option value="">Select Driver</option>
                <?php foreach ($drivers as $driver){ 
                if($driver->user_type=='DRIVER'){
                ?>
                    <option value="<?= $driver->id; ?>"><?= $driver->name; ?>(<?= $driver->staff_code; ?>)</option>
                <?php }} ?>
            </select>
        </div>

                            <!-- Location -->
                                               <div class="form-group">
                                <label for="year">Year</label>
                                <select class="form-control" name="year" id="year" required>
                                    <?php 
                                    $currentYear = date('Y');
                                    for ($y = 2023; $y <= 2040; $y++): ?>
                                        <option value="<?= $y; ?>" <?= $y == $currentYear ? 'selected' : ''; ?>><?= $y; ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label for="month">Month</label>
                                <select class="form-control" name="month" id="month" required>
                                    <?php
                                    $currentMonth = date('n');
                                    $months = [
                                        "January", "February", "March", "April", "May", "June",
                                        "July", "August", "September", "October", "November", "December"
                                    ];
                                    foreach ($months as $index => $month): ?>
                                        <option value="<?= $index + 1; ?>" <?= ($index + 1) == $currentMonth ? 'selected' : ''; ?>><?= $month; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                 

                            <!-- Amount -->
                            <div class="form-group">
                                <label for="amount">Amount</label>
                                <input class="uk-input" id="amount" name="amount" type="number" placeholder="Enter Amount" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="amount">Remark</label>
                                <input class="uk-input" id="remark" name="remark" type="text" placeholder="Enter remark" >
                            </div>

                            <!-- Submit and Excel Buttons -->
                            <div class="form-group">
                                <label>.</label><br>
                                <button type="submit" class="uk-button uk-button-primary">Submit</button>
                            </div>

                        </div>
                    </form>
                </div>
            </div>
                                <div class="uk-card uk-card-body uk-card-default uk-card-small uk-width-1-1@m">
<!-- Form for filtering the data -->
<form id="selectionForm" action="<?php echo base_url(); ?>/admin/adjust_salary" method="post">
    <div class="uk-grid-small uk-child-width-expand" uk-grid>
        <!-- Year selection -->
        <div class="form-group">
            <label for="year">Year</label>
            <select class="form-control" name="year" id="year">
                <?php 
                $currentYear = date('Y');
                for ($y = 2023; $y <= 2040; $y++): ?>
                    <option value="<?= $y; ?>" <?= $y == $currentYear ? 'selected' : ''; ?>><?= $y; ?></option>
                <?php endfor; ?>
            </select>
        </div>

        <!-- Month selection -->
        <div class="form-group">
            <label for="month">Month</label>
            <select class="form-control" name="month" id="month">
                <?php
                $currentMonth = date('n');
                $months = [
                    "January", "February", "March", "April", "May", "June",
                    "July", "August", "September", "October", "November", "December"
                ];
                foreach ($months as $index => $month): ?>
                    <option value="<?= $index + 1; ?>" <?= ($index + 1) == $currentMonth ? 'selected' : ''; ?>><?= $month; ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- Location selection -->
  

        <!-- Submit button for filtering -->
        <div class="form-group">
            <label>.</label><br>
            <button type="submit" class="btn btn-primary">Filter</button>
        </div>
    </div>
</form>

                    </div>
                    

                        <div class="uk-card uk-card-body uk-card-default uk-card-small uk-width-1-1@m">
                <table class="display" id="row_create" style="width:100%">
                    <thead>
                        <tr>
                            <th>Sl.No</th>
                            <th>Driver Name</th>
                            <th>Adjust Amount</th>
                            <th>Month</th>
                            <th>Remark</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $i = 1;
                        foreach ($allamount as $amount):
                              

?>
                            <tr>
                                <td><?= $i++; ?></td>
                                <td><?php echo $amount->driver_name; ?></td>
                                <td><?php echo $amount->amount; ?></td>
                                <td><?php echo $amount->month; ?></td>
                                <td><?php echo $amount->remark; ?></td>
                                <td>
                                    <a class="btn btn-success" href="<?php echo base_url(); ?>/Admin/edit_adjust_salary/<?php echo $amount->id; ?>">Edit</a>
                                    <a class="btn btn-danger" href="<?php echo base_url(); ?>/Admin/delete_adjust_salary/<?php echo $amount->id; ?>">Delete</a>
                                </td>

                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                           <th>Sl.No</th>
                            <th>Driver Name</th>
                            <th>Adjust Amount</th>
                            <th>Month</th>
                            <th>Remark</th>
                            <th>Action</th>
                        </tr>
                    </tfoot>
                </table>
            </div>

        </div>
    </div>
    </div>    
</div>


<?php include("footer.php"); ?>